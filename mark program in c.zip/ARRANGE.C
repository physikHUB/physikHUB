void tableheads(int,int,int);
void extraction(char *[],char *[],int);
void listitem(char *,int,int,int);
int  popupscroll(char *[],int,int,int,int);
int comboscroll(char *[],int,int,int,int);
void tableItem(char *,char *,int,int,int);
int  tableresponse(char *[],char *[],int,int,int,int,int,int);
int popuptable(char *[],char *[],int,int,int,int);
int  scrollresponse(char *[],int,int,int,int);
void drawscroll(int,int,int);
void tablehead(int,int);

//for main interface.
void menuitem(char *,int,int,int);
void menuplate(int,int,int);
void mainscreen(void);
int popupmenuv(char *[],int,int,int,int);
void displaymenuv(char *[],int,int,int);
int getresponsev(char *[],int,int,int,int);
void displaymenuh(char *[],int,int,int);
void menuitemh(char *,int,int,int);
int getresponseh(char *[],int,int,int,int);
void helpbox(void);
void waiting(int,int);
void aboutus(void);
//global variables.
#define ENTER 13
#define ESC 27
char *mainmenu[6]={ "Application",
		    "Students",
		    "Marks",
		    "Display",
		    "ReportCard",
		    "Help"
		    };

char *submenu1[3]={"Add Student",
		  "Modify Student",
		  "Delete Student"
		 };

char *submenu2[3]={"Add Mark",
		  "Modify Mark",
		  "Delete Mark"
		 };


char *submenu3[2]={"List Students",
		  "List Marks"
		   };

char *submenu4[1]={"Generate"};

char *submenu5[2]={"Shortcut",
		   "Detailed"
		   };

char *submenu6[1]={"Quit    "
		  };
char *help[17]={"Quiting from the application",
	       "Operation for student's demographics",
	       "Operation for student's marks",
	       "Operation for displaying marks and students ",
	       "Operation for creation of report cards",
	       "Help",
	       "Adding student to the system",
	       "Modifying student's demographics",
	       "Deleting student from the system",
	       "Adding marks of student to the system",
	       "Modifying marks of student in the system",
	       "Deleting mark of the student from the system",
	       "Displaying demographics of all students",
	       "Displaying marks of all students",
	       "Creating report cards for an individual student",
	       "Providing a short cut help",
	       "Providing detailed help"
		 };

int comboscroll(char *listing[],int count,int sr,int sc,int er)
{
char ch;
int choice,cflag;
combooutline(sr,sc,er,sc+15,0,0);
if(count==0)
	{
	outtextxy(sr+5,sc+2,"None");
	return -1;
	}
else
{
cflag=-1;
while(1)
{
ch=(int)getch();
switch(ch)
	{
	case 32:choice=popupscroll(listing,count,sr,sc,er);cflag=0;break;
	case 9:case 13:
	if(cflag==-1)
	continue;
	else
	return(choice);
	default:continue;
	}
}

}
}

int popupscroll(char *listing[],int count,int sr,int sc,int er)
{
unsigned size;
void  *buff='\0';
int choice=0;
char ch;
combooutline(sr,sc,er,sc+15,0,1);
size=imagesize(sr,sc+16,er,sc+140);
buff=malloc(size);
getimage(sr,sc+16,er+1,sc+142,buff);
if(count<10)
comboplate(sr,sc+16,er-15,count);
else
comboplate(sr,sc+16,er-15,9);
combooutline(sr,sc,er,sc+15,0,32);
choice=scrollresponse(listing,count,sr-4,sc+17,er);
putimage(sr,sc+16,buff,0);
free(buff);
return(choice);
}



void drawscroll(int sr,int sc,int len)
{
threedbar(sr,sc,10,4,7,1);
setcolor(0);
outtextxy(sr+4,sc+2,"");
setfillstyle(1,7);
bar(sr,sc+11,sr+14,sc+len);
threedbar(sr,sc+len,10,4,7,1);
setcolor(0);
outtextxy(sr+4,sc+len+2,"");
setcolor(15);
line(sr+15,sc+2,sr+15,sc+len+10);
threedbar(sr,sc+11,len-12,4,7,1);
}

void tablehead(int sr,int sc)
{
int count;
count=strlen("STDID");
threedbar(sr,sc,10,count*10,7,1);
setcolor(0);
outtextxy(sr+8,sc+2,"STDID");
threedbar(sr+count*12+1,sc,10,188,7,1);
sr=sr+count*12+1;
setcolor(0);
outtextxy(sr+84,sc+2,"NAME");
}


int scrollresponse(char *listing1[],int count,int sr,int sc,int er)
{
int inc=0,ascii,scan,fac=9,flag=1,i,sel=0,choice=0;
if(count>=10)
{
drawscroll(er-14,sc-1,116);
while(flag>=0)
{
	for(i=choice;i<count;i++)
	{
	if(i==sel+choice)
	listitem(listing1[sel+choice],sr+5,sc+2+inc,1);
	else listitem(listing1[i],sr+5,sc+2+inc,0);
	inc+=11;

	if((i-choice)>=9)
		{
		fac=9;
		inc=sel*11;
		while(1)
		{
		ascii=(int)getch();
			if(ascii!=0)
			{
			switch(ascii)
				{
				case 13:
				combooutline(sr+4,sc-17,er,sc-2,0,1);
				outtextxy(sr+8,sc-12,listing1[i-(fac-sel)]);  //some particular assignment should take place over here.
				flag=-1;
				break;

				case 27:
				exit(1);
				}
			break;              //to come out of the loop.
			}


			else if(ascii==0)
			{
			scan=(int)getch();
			switch(scan)
				{
				case 80:                  //down arrow key.
				listitem(listing1[i-(fac-sel)],sr+5,sc+2+inc,0);
				fac--;
				inc+=11;
				break;
				case 72:                  //up arrow key.
				listitem(listing1[i-(fac-sel)],sr+5,sc+2+inc,0);
				fac++;
				inc-=11;
				break;
				default:
				continue;
				}

		if((fac-sel)>9)
		{
		i--;
		choice--;
		if(i<(fac-sel))                            //when i reaches the first item in the list.
			{
			choice=0;
			}
		setfillstyle(1,57);                      	//scrolling  up
		bar(er-14,sc+10,sr+123,sc+10+choice*2);
		threedbar(er-14,sc+10+choice*1,104-choice*1,4,7,1);
		sel=0;
		inc=0;
		break;
		}
		else if((fac-sel)<=0)
		{
		i++;
		choice++;
		if(i==count)                             	//when i==count.
		choice--;
		setfillstyle(1,57);                         	 //scroll down.
		bar(er-14,sc+10,sr+123,sc+10+choice*2);
		threedbar(er-14,sc+10+choice*1,104-choice*1,4,7,1);
		sel=9;
		inc=0;
		break;
		}

	   else
	   listitem(listing1[i-(fac-sel)],sr+5,sc+2+inc,1);
	     }			//end of if associated with ascii=0.


	 }             		//end of inner while

	break;          	//to come out of the if condition.
	}              		//end of if associated with the no of items.



    }      			//end of for loop.


 }                      	//end of outer while loop.

return(i-(fac-sel));
}                               //end of outer if.

else
{
comboplate(sr+4,sc-1,er+1,count+1);
for(i=1;i<=count;i++)
	{
	comboitem(listing1[i-1],sr+5,sc-8+(i*13),er,0);
	}
i=getresponsec(listing1,count,sr+4,sc-12,er);
combooutline(sr+4,sc-17,er,sc-2,0,1);
outtextxy(sr+8,sc-12,listing1[i]);
return(i);
}


}                       	//end of function definition.


void listitem(char *item,int sr,int sc,int vis)
{
int bcol,fcol;
switch(vis)
	{
	case 1:
	bcol=1;
	fcol=15;
	break;
	case 0:
	bcol=63;
	fcol=0;
	break;
	}
	setcolor(7);
	setfillstyle(1,bcol);
	bar(sr,sc+1,sr+103,sc+10);
	setcolor(fcol);
	outtextxy(sr+5,sc+2,item);
}

int tableresponse(char *list1[],char *list2[],int count,int num,int sr,int sc,int er,int status)
{
int inc=0,ascii,scan,fac=9,flag=1,i,sel=0,choice=0;
char ch;
if(count>=num)
{
drawbox(sr+2,sc-10,er+130,sc+305,0,0,2);
tablehead(sr+6,sc-9);
drawscroll(er+112,sc+2,290);
while(flag>=0)
{
	for(i=choice;i<count;i++)
	{
	if(i==sel+choice)
	tableItem(list1[sel+choice],list2[sel+choice],sr+5,sc+2+inc,1);
	else tableItem(list1[i],list2[i],sr+5,sc+2+inc,0);
	inc+=15;

	if((i-choice)>=num-1)
		{
		fac=num-1;
		inc=sel*15;
		while(1)
		{
		ascii=(int)getch();
			if(ascii!=0)
			{
			switch(ascii)
				{
				case 13:
				if(status==1)
				{
				tableItem(list1[i-(fac-sel)],list2[i-(fac-sel)],sr+5,sc+2+inc,0);
				}
				flag=-1;
				break;
				}
			break;              //to come out of the loop.
			}


			else if(ascii==0)
			{
			scan=(int)getch();
			switch(scan)
				{
				case 80:                  //down arrow key.
				tableItem(list1[i-(fac-sel)],list2[i-(fac-sel)],sr+5,sc+2+inc,0);
				fac--;
				inc+=15;
				break;
				case 72:                  //up arrow key.
				tableItem(list1[i-(fac-sel)],list2[i-(fac-sel)],sr+5,sc+2+inc,0);
				fac++;
				inc-=15;
				break;
				default:
				continue;
				}

		if((fac-sel)>num-1)
		{
		i--;
		choice--;
		inc=0;
		if(i<(fac-sel))                            //when i reaches the first item in the list.
		choice=0;
		setfillstyle(1,57);                      	//scrolling  up
		bar(er+112,sc+13,er+125,sc+13+choice*2);
		threedbar(er+112,sc+13+choice*1,278-choice*1,4,7,1);
		sel=0;
		break;
		}
		else if((fac-sel)<=0)
		{
		i++;
		choice++;
		if(i==count)                             	//when i==count.
		choice--;
		setfillstyle(1,57);                         	 //scroll down.
		bar(er+112,sc+13,er+125,sc+13+choice*2);
		threedbar(er+112,sc+13+choice*1,278-choice*1,4,7,1);
		sel=num-1;
		inc=0;
		break;
		}

	   else
	   tableItem(list1[i-(fac-sel)],list2[i-(fac-sel)],sr+5,sc+2+inc,1);
	     }			//end of if associated with ascii=0.


	 }             		//end of inner while

	break;          	//to come out of the if condition.
	}              		//end of if associated with the no of items.



    }      			//end of for loop.


 }                      	//end of outer while loop.

return(i-(fac-sel));
}                               //end of outer if.

else
{
  if(count==0)
    {
    tablehead(sr+6,sc-9);
    setcolor(0);
    setlinestyle(0,0,1);
    setfillstyle(1,15);
    bar3d(sr+7,sc+2,sr+200,sc+15,0,0);
    setcolor(0);
    outtextxy(sr+10,sc+5,"None");
       while(1)
       {
	ch=getch();
	if((int)ch==13)
	return -1;
	else
	continue;
       }
    }
else
	{
	drawbox(sr+2,sc-10,er+130,sc+305,0,0,2);
	tablehead(sr+6,sc-9);
	i=popuptable(list1,list2,count,sr+5,sc-13,status);
	return(i);
	}


}


}                       	//end of function definition.


int popuptable(char *list1[],char *list2[],int count,int sr,int sc,int status)
{
int i,choice=0,scan,inc=15,ascii;
for(i=1;i<=count;i++)
	{
	if(i==1)
	tableItem(list1[i-1],list2[i-1],sr,sc+inc,1);
	else
	tableItem(list1[i-1],list2[i-1],sr,sc+inc,0);
	inc+=15;
	}
while(1)
	{
	inc=(choice+1)*15;
	ascii=(int)getch();
	if(ascii==0)
		{
		scan=(int)getch();
		switch(scan)
			{
			case 80:  					//down arrow key
			tableItem(list1[choice],list2[choice],sr,sc+inc,0);   	//normalizing the highlighted
			choice++;
			inc+=15;
			break;
			case 72:  					//up arrow key.
			tableItem(list1[choice],list2[choice],sr,sc+inc,0);       //normalizing the selection.
			choice--;
			inc-=15;
			break;
			}

	if(choice==-1)     			 //if the first item is highlighted and up arrow is pressed.
		{
		choice=0;
		inc=15;             	//positioning to the last item of the menu.
		}
	if(choice==count)    			//if the last item is highlighted and down arrow is pressed.
		{
		choice=count-1;
		inc=count*15;//(count-1)*13;           	  //positioning to the first item of the menu.
		}

	tableItem(list1[choice],list2[choice],sr,sc+inc,1);
   }  //end of if.

if(ascii==13)
	{
	 if(status==1)
	 tableItem(list1[choice],list2[choice],sr,sc+inc,0);

 return(choice);
	}

    }     //end of while.


}


void tableItem(char *item1,char *item2,int sr,int sc,int vis)
{
int bcol,fcol,len1,len2;
switch(vis)
	{
	case 1:
	bcol=1;
	fcol=15;
	break;
	case 0:
	bcol=63;
	fcol=0;
	break;
	}
	setfillstyle(1,bcol);
	bar(sr,sc,sr+60,sc+15);
	setcolor(7);
	rectangle(sr,sc,sr+60,sc+15);
	setcolor(fcol);
	outtextxy(sr+3,sc+4,item1);
	sr+=60;
	setfillstyle(1,15);
	bar(sr,sc,sr+200,sc+15);
	setcolor(7);
	rectangle(sr,sc,sr+200,sc+15);
	setcolor(0);
	outtextxy(sr+10,sc+4,item2);

}

void menuitem(char *item,int row,int col,int vis)
{
switch(vis)
	{
	case 0:
	setfillstyle(1,WHITE);
	bar(row,col-2,row+175,col+12);
	setcolor(BLACK);
	outtextxy(row+2,col,item);
	break;
	case 1:
	setcolor(1);
	setfillstyle(1,58);
	bar3d(row,col-2,row+175,col+12,0,0);
	setcolor(BLACK);
	outtextxy(row+2,col,item);
	break;
	default:
	setfillstyle(1,WHITE);
	bar(row,col-2,row+175,col+12);
	setcolor(BLACK);
	outtextxy(row+2,col,item);
		}
}



void menuplate(int x1,int y1,int count)
{
setfillstyle(1,56);
bar(x1+2,y1+2,x1+217,y1+(count*30)+2);      //shadow to the menu.
setcolor(1);
setfillstyle(1,7);
bar3d(x1,y1,x1+25,y1+(count*30),0,0);
setfillstyle(1,WHITE);
bar3d(x1+25,y1,x1+215,y1+(count*30),0,0);
}

void mainscreen()
{
threedbar(0,0,480,640,7,1);
drawbox(2,2,getmaxx()-4,getmaxy()-2,0,0,1);
drawbox(10,getmaxy()-18,getmaxx()-10,getmaxy()-6,0,0,2);
drawbox(3,3,getmaxx()-5,20,1,7,3);
setcolor(15);
outtextxy(7,7,"MarkMania-2003");
drawbox(8,22,getmaxx()-10,40,63,7,3);
drawbox(10,42,getmaxx()-10,getmaxy()-20,0,0,2);
displaymenuh(mainmenu,6,10,27);
}

int popupmenuv(char *menu[],int count,int sr,int sc,int helpn)
{
int i,len=0,l,area,choice;
unsigned int size;
void *p;
for(i=0;i<count;i++)		//to find out the longest menuitem.
{
l=strlen(menu[i]);
if(l>len)
len=l;
}
	/*calculate the are required to save screen contents where menu is to be popped up*/
size=imagesize(sr,sc,sr+len+210,sc+count+100+5);
p=malloc(size);
getimage(sr,sc,sr+len+210,sc+count+100+5,p);
menuplate(sr,sc,count);
displaymenuv(menu,count,sr+27,sc+10);
choice=getresponsev(menu,count,sr+27,sc+10,helpn);                                  //after an event the original screen content is restored back.
putimage(sr,sc,p,0);
free(p);
return (choice);
}

void displaymenuv(char *menu[],int count,int sr,int sc)
{
int i;
for(i=0;i<count;i++)
{
setcolor(BLACK);
menuitem(menu[i],sr,sc,0);  //using my own function definition.
sc+=15;
setcolor(7);
line(sr,sc,sr+180,sc);
sc+=15;
}

}


int getresponsev(char *menu[],int count,int sr,int sc,int helpn)
{
int choice=0,len,scan,inc=0,ascii;
char ch;
menuitem(menu[choice],sr,sc,1);
helpbox();
outtextxy(50,getmaxy()-16,help[helpn]);
while(1)
{
ch=getch();
ascii=(int)ch;
if((int)ch==0)
	{
	ch=getch();
	scan=(int)ch;
	switch(scan)
	{
	case 80:  				//down arrow key
	menuitem(menu[choice],sr,sc+inc,0);  	//normalizing the highlighted item.
	choice++;
	helpn++;
	inc+=30;
	break;

	case 72:  //up arrow key.
	menuitem(menu[choice],sr,sc+inc,0);     //normalizing the highlighted item.
	choice--;
	helpn--;
	inc-=30;
	break;
	case 77:				//right arrow key
	return(77);
	case 75:				//left arrow key
	return(75);
	}

if(choice==-1)     			 //if the first item is highlighted and up arrow is pressed.
	{
	choice=count-1;
	helpn=helpn+count;
	inc+=(count*30);             	//positioning to the last item of the menu.
	}
if(choice==count)    			//if the last item is highlighted and down arrow is pressed.
	{
	choice=0;
	helpn=helpn-count;
	inc-=(count*30);           	  //positioning to the first item of the menu.
	}

menuitem(menu[choice],sr,sc+inc,1);
helpbox();
outtextxy(50,getmaxy()-16,help[helpn]);
}
if (ascii==ENTER)
return(choice);
if(ascii==ESC)
{
displaymenuh(mainmenu,6,10,27);
return(ESC);
}


}

}

void displaymenuh(char *menu[],int count,int sr,int sc)
{
int i;
int len;
menuitemh(menu[0],sr,sc,0);
for(i=1;i<count;i++)
	{
	sr+=110;
	menuitemh(menu[i],sr,sc,0);  //using my own function definition.
	}
}

void menuitemh(char *item,int row,int col,int vis)
{
int len;
len=strlen(item);
switch(vis)
	{
	case 0:
	setfillstyle(1,63);
	bar(row,col-2,row+(len*10),col+12);
	setcolor(BLACK);
	outtextxy(row+2,col,item);
	break;
	case 1:
	setcolor(1);
	setfillstyle(1,58);
	bar3d(row,col-2,row+(len*10),col+12,0,0);
	setcolor(0);
	outtextxy(row+2,col,item);
	break;
	}
}

int getresponseh(char *menu[],int count,int sr,int sc,int helpn)
{
int choice=0,len,scan,inc=0,ascii,wid;
char ch;
menuitemh(menu[choice],sr,sc,1);
helpbox();
setcolor(0);
outtextxy(50,getmaxy()-16,help[helpn]);
while(1)
{
ch=getch();
ascii=(int)ch;
if((int)ch==0)
	{
	ch=getch();
	scan=(int)ch;
	switch(scan)
	{
	case 77:  				//right arrow key
	menuitemh(menu[choice],sr+inc,sc,0);  	//normalizing the highlighted item.
	choice++;
	helpn++;
	inc+=110;
	break;

	case 75:  //left arrow key.
	menuitemh(menu[choice],sr+inc,sc,0);     //normalizing the highlighted item.
	choice--;
	helpn--;
	inc-=110;
	break;
	}

if(choice==-1)    			  //if the first item is highlighted and left arrow is pressed.
	{
	choice=count-1;
	helpn=helpn+count;
	inc+=(count*110);             //positioning to the last item of the menu.
	}
if(choice==count)    		//if the last item is highlighted and right arrow is pressed.
	{
	choice=0;
	helpn=helpn-count;
	inc-=(count*110);           //positioning to the first item of the menu.
	}

menuitemh(menu[choice],sr+inc,sc,1);
helpbox();
setcolor(0);
outtextxy(50,getmaxy()-16,help[helpn]);
}
else
{
	if(ascii==13)
	return (choice);


}

}
}
void helpbox()
{
setfillstyle(1,7);
bar(50,getmaxy()-16,450,getmaxy()-8);
}

void aboutus()
{
int i,size;
setcolor(BLACK);
setfillstyle(1,WHITE);
bar3d(100,100,400,300,1,0);
for(i=0;i<=40;i+=2)
{
setcolor(CYAN);
line(101,101+i,180,101+i);
}
setfillstyle(1,57);
bar(101,141,399,165);
setfillstyle(1,1);
bar(101,166,399,169);
for(i=0;i<10;i+=2)
{
setcolor(CYAN);
line(150,170+i,399,170+i);
}
setfillstyle(1,1);
bar(150,120,200,155);
setfillstyle(1,WHITE);
bar(153,123,197,152);
setfillstyle(1,1);
bar(160,128,190,147);
setfillstyle(1,WHITE);
bar(162,130,188,145);
settextstyle(1,0,1);
setcolor(1);
outtextxy(168,126,"M");
settextstyle(12,0,0);
setcolor(BLACK);
outtextxy(210,116,"a&s");
outtextxy(285,130,"2003");
outtextxy(280,180,"Meambu Office");
outtextxy(140,210,"Licensed to");
outtextxy(145,265,"Copyright  Meambu Coproration");
outtextxy(145,275,"All rights reserved");
setcolor(7);
line(138,218,399,218);
setcolor(CYAN);
settextstyle(14,0,0);
outtextxy(140,224,"Sunil Kumar Thapa");
settextstyle(10,0,1);
setcolor(GREEN);
outtextxy(210,112,"MARK");
getch();
setfillstyle(1,2);
bar(100,100,402,300);
settextstyle(14,0,0);        //for other branches.
}
