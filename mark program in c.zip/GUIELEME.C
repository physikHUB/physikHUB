//GUI contains all the basic components required for graphic user interface.
//prototype for textfunctions.
void getstring(char [],int,int,int,int,int);
void textarea(char [],int,int,int,int,int,int);
void drawcursor(int,int);

//prototype for number function.
void getnum(char [],int,int,int,int,int);

//prototype for optiongroup
void optionitem(char *,int,int,int);
void radiobutton(int,int,int);
void displayoption(char *[],int,int,int,int);
int getresponseo(char *[],int,int,int);
int optiongroup(char *[],int,int,int,int);

//prototype declaration for combobox
void comboitem(char *,int,int,int,int);
void combooutline(int,int,int,int,int,int);
void comboplate(int,int,int,int);
void displaycombo(char *[], int, int, int,int,int);
int popupcombo(char *[],int,int,int,int,int);
int getresponsec(char *[],int,int,int,int);
int combobox(char *[],int,int,int,int,int);

//prototype for rectangular box and command button.
void displaybuttons(char *[],int,int,int,int);
int buttonresponse(char *[],int,int,int,int);
void button(int,int,int,char *,int,int,int);
void drawbox(int,int,int,int,int,int,int);
void label(int,int,int,int,char *);
void drawline(int,int,int,int,int);
void threedbar(int,int,int,int,int,int);
//functions for error messages.
void errmessage(char *,char *,int,int,int,int);
int deletemessage(int,int,int,int);

//function definition for command button.
void displaybuttons(char *butlist[],int count,int blen,int sr,int sc)
{
int i,inc=0;
for(i=0;i<count;i++)
{
button(sr+inc,sc,blen,butlist[i],0,0,0);
inc+=blen+10;
}
return;
}

//to get a response for buttons.
int buttonresponse(char *butlist[],int count,int blen,int sr,int sc)
{
int choice=0,ascii,scan,inc=0;
button(sr+inc,sc,blen,butlist[choice],1,0,4);  //first item highlighted.
while(1)
	{
	ascii=(int)getch();
	if(ascii==0)
		{
		scan=(int)getch();
		switch(scan)
			{
			case 77:
			button(sr+inc,sc,blen,butlist[choice],0,0,0);  //normalize the highlighted one.
			choice++;
			inc+=blen+10;
			break;
			case 75:
			button(sr+inc,sc,blen,butlist[choice],0,0,0);  //normalize the highlighted one.
			choice--;
			inc-=blen+10;
			break;
			}
		if(choice==count)
		   {
		   choice=0;
		   inc=0;
		   }
		 if(choice<0)
		   {
		   choice=count-1;
		   inc=(count-1)*(blen+10);
		   }


		button(sr+inc,sc,blen,butlist[choice],1,0,4); // highlight the appropriate item.
		}

	if(ascii==13)
		{
		button(sr+inc,sc,blen,butlist[choice],0,13,4);
		delay(200);
		button(sr+inc,sc,blen,butlist[choice],0,0,0);
		return(choice);
		}
	if(ascii==27)
		{
		button(sr+inc,sc,blen,butlist[choice],0,0,0);
		choice=27;
		return(choice);
		}
	}


}

//to create different states of buttons.
void button(int sr,int sc,int len,char *bname,int hl,int key,int forecol)
{
int count;
count=strlen(bname);
if(key!=13)                               //if enter key is pressed.
    {
	setfillstyle(1,0);
	bar(sr,sc,sr+len,sc+20);
	setfillstyle(1,15);
	bar(sr,sc,sr+len-1,sc+19);
	setfillstyle(1,7);
	bar(sr+1,sc+1,sr+len-1,sc+19);
     }
else
     {
	setfillstyle(1,0);
	bar(sr,sc,sr+len,sc+20);
	setfillstyle(1,15);
	bar(sr+2,sc+2,sr+len-1,sc+19);
	setfillstyle(1,7);
	bar(sr+2,sc+2,sr+len-1,sc+18);
      }

if(hl==1)                                   //if it is selected.
      {
	setfillstyle(1,0);
	bar(sr,sc,sr+len,sc+20);
	setfillstyle(1,15);
	bar(sr+1,sc+1,sr+len-2,sc+18);
	setfillstyle(1,7);
	bar(sr+2,sc+2,sr+len-2,sc+18);
	setcolor(0);
	setlinestyle(1,0,1);
	rectangle(sr+3,sc+2,sr+len-3,sc+17);
	}

count*=7;
len-=count;
len/=2;
setcolor(forecol);
outtextxy(sr+len,sc+6,bname);
setlinestyle(0,0,1);                           //setting default line style.
return;
}

//function definition for combobox outline.
void combooutline(int sr,int sc,int er,int ec,int hl,int key)
{
setfillstyle(1,0);
bar(sr,sc,er,ec);
setfillstyle(1,15);
bar(sr+1,sc+1,er+1,ec+1);
setfillstyle(1,7);
bar(sr+1,sc+1,er,ec);
setfillstyle(1,15);
bar(sr+1,sc+1,er-1,ec-1);
if(key!=32)                      	//if space key is not pressed.
{
 threedbar(er-15,sc+1,13,5,7,1);
}
else
{
setfillstyle(1,0);
bar(er-15,sc+1,er-2,sc+12);
setfillstyle(1,15);
bar(er-14,sc+2,er-1,sc+13);
setfillstyle(1,7);
bar(er-14,sc+2,er-2,sc+13);
}

if(hl==1)                                   //if selected.
{
setcolor(0);
setfillstyle(1,0);
bar(sr+2,sc+2,er-21,sc+14);
}
setcolor(0);
outtextxy(er-10,sc+5,"");
}

//function definition for combobox
int combobox(char *subname[],int count,int sr,int sc,int er,int ec)
{
int choice=0,i,cflag;
char ch;
combooutline(sr,sc,er,ec,0,1);
if(count==0)
 {
 outtextxy(sr+5,sc+3,"None");
 return 0;
 }
else
{
cflag=-1;
while(1)
{
ch=(int)getch();
switch(ch)
	{
	case 32:choice=popupcombo(subname,count,sr,sc,er,ec);cflag=0;break;
	case 9:case 13:
	if(cflag==-1)
	continue;
	else
	return(choice);
	default:continue;
	}

}

}
}

//function definition to create or erase the combobox's list.
int popupcombo(char *subject[],int count,int sr,int sc,int er,int ec)
{
int size,choice;
void *buffer;
size=imagesize(sr,ec+2,er+1,ec+2+(count*14));
buffer=malloc(size);
getimage(sr,ec+2,er+1,(ec+2+count*14),buffer);
displaycombo(subject,count,sr,sc,er,ec);
choice=getresponsec(subject,count,sr,sc,er);
combooutline(sr,sc,er,ec,0,0);
setcolor(0);
outtextxy(sr+5,sc+4,subject[choice]);
putimage(sr,ec+2,buffer,0);
free(buffer);
return (choice);
}

//function definition to get choice for the items in combobox.
int getresponsec(char *subject[],int count,int sr,int sc,int er)
{
int choice=0,scan,inc=13,ascii;
char ch;
comboitem(subject[choice],sr+1,sc+4+inc,er,1);
while(1)
	{
	ch=getch();
	ascii=(int)ch;
	if((int)ch==0)
		{
		ch=getch();
		scan=(int)ch;
		switch(scan)
			{
			case 80:  					//down arrow key
			comboitem(subject[choice],sr+1,sc+4+inc,er,0);   	//normalizing the highlighted
			choice++;
			inc+=13;
			break;

			case 72:  					//up arrow key.
			comboitem(subject[choice],sr+1,sc+4+inc,er,0);       //normalizing the selection.
			choice--;
			inc-=13;
			break;
			default:continue;
			}

	if(choice==-1)     			 //if the first item is highlighted and up arrow is pressed.
		{
		choice=count-1;
		inc+=(count*13);             	//positioning to the last item of the menu.
		}
	if(choice==count)    			//if the last item is highlighted and down arrow is pressed.
		{
		choice=0;
		inc-=(count*13);           	  //positioning to the first item of the menu.
		}

	comboitem(subject[choice],sr+1,sc+4+inc,er,1);
	  }

if(ascii==13)
return(choice);
    }

}

//function definition to display the combobox in active form.
void displaycombo(char *list[], int count, int sr, int sc,int er,int ec)
{
int i;
combooutline(sr,sc,er,ec,0,32);
comboplate(sr,sc+16,er+1,count);
for(i=1;i<=count;i++)
comboitem(list[i-1],sr+1,sc+6+(i*13),er,0);
}


//to create a area for the items in the combobox.
void comboplate(int sr,int sc,int er,int count)
{
setcolor(0);
setlinestyle(0,1,1);
setfillstyle(1,15);
bar3d(sr,sc+1,er,(sc+count*14),0,0);
}

//to display an individual comboboxitem.
void comboitem(char *text,int sr,int sc,int er,int vis)
{

	switch(vis)
	{
	case 0:
	setcolor(BLACK);
	setfillstyle(1,WHITE);
	break;
	case 1:
	setcolor(WHITE);
	setfillstyle(1,1);
	break;
	}
	bar(sr,sc+1,er,sc+11);
	outtextxy(sr+3,sc+3,text);
return;
}


//to create an optiongroup.
int optiongroup(char *optlist[],int count, int sr,int sc,int er)
{
int choice;
displayoption(optlist,count,sr,sc,er);
choice=getresponseo(optlist,count,sr,sc);
return (choice);
}

//to display an option item.
void optionitem(char *item,int sr,int sc,int vis)
{
int count,col,lcol;
count=strlen(item);
setcolor(1);
switch(vis)
	{
	case 1:
	col=0;
	lcol=0;
	break;
	case 0:
	col=15;
	lcol=7;
	break;
	}
	radiobutton(sr,sc,col);
	setcolor(lcol);
	setlinestyle(1,0,1);
	rectangle(sr+18,sc,sr+count*12,sc+12);
	setcolor(0);
	settextstyle(11,0,1);
	outtextxy(sr+22,sc+2,item);

return;
}

//to draw a rectangular box.
void drawbox(int sr,int sc,int er,int ec,int fcol,int bcol,int style)
{
setlinestyle(0,0,1);
switch(style)
	{
	case 1:
	setcolor(15);
	rectangle(sr,sc,er,ec);
	setcolor(56);
	line(sr,sc-1,er,sc-1);
	line(er-1,sc+1,er-1,ec-1);
	line(er-1,ec-1,sr+1,ec-1);
	rectangle(sr-1,sc-1,sr-1,ec);
	break;
	case 2:
	setcolor(0);
	line(sr,sc,er,sc);
	line(sr,ec,sr,sc);
	setcolor(15);
	line(er,sc,er,ec);
	line(er,ec,sr,ec);
	break;
	case 3:
	setcolor(bcol);
	setfillstyle(1,fcol);
	bar3d(sr,sc,er,ec,0,0);
	break;
	}
return;
}

//to create a rectangular radio button.
void radiobutton(int x,int y,int col)
{
int i;
drawbox(x,y,x+15,y+12,0,0,2);
setfillstyle(1,15);
bar(x+1,y+1,x+13,y+10);
setcolor(col);
for(i=0;i<4;i++)
circle(x+7,y+6,i);
}

//to create an optionlist.
void displayoption(char *list[],int count,int sr,int sc,int er)
{
int i;
drawbox(sr,sc,er,sc+4+count*15,0,0,1);
	for(i=0;i<count;i++)
	{
	optionitem(list[i],sr+4,sc+4+i*14,0);
	}

}

//to get a choice in the option group.
int getresponseo(char *list[],int count, int sr,int sc)
{
int choice=0,scan,inc=0,ascii;
char ch;
optionitem(list[choice],sr+4,sc+4+inc,1);
while(1)
{
ch=getch();
ascii=(int)ch;
if((int)ch==0)
	{
	ch=getch();
	scan=(int)ch;
	switch(scan)
	{
	case 80:  				        //up arrow key
	optionitem(list[choice],sr+4,sc+4+inc,0);  //normalizing the selected choice
	choice++;
	inc+=14;
	break;

	case 72:  					//left arrow key.
	optionitem(list[choice],sr+4,sc+4+inc,0);  		//normalizing the highlighted choice
	choice--;
	inc-=14;
	break;
	}

	if(choice==-1)     			 //if the first item is highlighted and up arrow is pressed.
		{
		choice=count-1;
		inc+=(count*14);             	//positioning to the last item of the menu.
		}
	if(choice==count)    			//if the last item is highlighted and down arrow is pressed.
		{
		choice=0;
		inc-=(count*14);           	  //positioning to the first item of the menu.
		}

	  optionitem(list[choice],sr+4,sc+4+inc,1);      //selecting the appropriate choice.
	}
if(ascii==13)                                       //if enter key is pressed.
return(choice);                                     //returning the current choice.

if(ascii==27)                                       //if escape key is pressed.
return(27);

}                                                    //end of while.
}                                                   //end of function.

//To get an unsigned integral value.
void  getnum(char string[],int sr,int sc,int size,int col,int vis)
{
int count=1,inc=0,ascii;
switch(vis)
{
	case 0:
	setfillstyle(1,0);
	bar(sr-4,sc-4,(sr+size*10),sc+14);
	setfillstyle(1,15);
	bar(sr-3,sc-3,(sr+size*10),sc+15);
	setfillstyle(1,7);
	bar(sr-3,sc-3,(sr+size*10-1),sc+14);
	setfillstyle(1,col);
	bar(sr-3,sc-3,(sr+size*10-2),sc+13);
	break;
	case 1:
	setfillstyle(1,0);
	bar(sr-4,sc-4,(sr+size*10),sc+14);
	setfillstyle(1,15);
	bar(sr-3,sc-3,(sr+size*10),sc+15);
	setfillstyle(1,7);
	bar(sr-3,sc-3,(sr+size*10-1),sc+14);
	setfillstyle(1,col);
	bar(sr-3,sc-3,(sr+size*10-2),sc+13);
	string[0]='\0';
	drawcursor(sr,sc);
	while((ascii=(int)getch())!=13)
	{
		if(count>size-2&&ascii!=8)//&&ascii!=9)
		{
		drawcursor(sr+inc,sc);
		continue;
		}
		if(count<=0)
		{
		setcolor(0);
		line(sr,sc,sr,sc+10);
		continue;
		}
	       if(ascii==8 && count>1)
		{
		count--;
		inc-=8;
		setfillstyle(1,col);
		string[count-1]='\0'; 	      //the selected letter is assigned null character.
		bar(sr+inc,sc,sr+inc+8,sc+10);
		drawcursor(sr+inc,sc);                  //cursor should come before any letter
		continue;
		}
	       if(ascii==9)                    //if tab key is pressed then break out of loop.
	       break;

	       if((ascii>0&&ascii<48)||ascii>57)
		{
		drawcursor(sr+inc,sc);
		continue;
		}
		if(ascii==0)
		{
	       ascii=(int)getch();
	       drawcursor(sr+inc,sc);
	       continue;
		  }

	string[count-1]=ascii;
	string[count]='\0';
	setfillstyle(1,col);
	bar(sr+inc,sc,sr+inc+8,sc+10);
	setcolor(15);
	outtextxy(sr,sc,string);
	drawcursor(sr+8+inc,sc);                 //cursor should come beyond any letter.
	count++;
	inc+=8;
	}                                        //end of while.
	string[count]='\0';                      //for tab key.
	setfillstyle(1,col);
	bar(sr+inc,sc,sr+inc+8,sc+10);
	setcolor(15);
	outtextxy(sr,sc,string);
	break;
	}                   					//end of switch.

}
//to get an string from the user.
void getstring(char string[],int sr,int sc,int size,int col,int vis)
{
int count=1,inc=0,ascii;
switch(vis)
{
	case 0:
	setfillstyle(1,0);
	bar(sr-4,sc-4,(sr+size*10),sc+14);
	setfillstyle(1,15);
	bar(sr-3,sc-3,(sr+size*10),sc+15);
	setfillstyle(1,7);
	bar(sr-3,sc-3,(sr+size*10-1),sc+14);
	setfillstyle(1,col);
	bar(sr-3,sc-3,(sr+size*10-2),sc+13);
	break;
	case 1:
	setfillstyle(1,0);
	bar(sr-4,sc-4,(sr+size*10),sc+14);
	setfillstyle(1,15);
	bar(sr-3,sc-3,(sr+size*10),sc+15);
	setfillstyle(1,7);
	bar(sr-3,sc-3,(sr+size*10-1),sc+14);
	setfillstyle(1,col);
	bar(sr-3,sc-3,(sr+size*10-2),sc+13);
	string[0]='\0';
	drawcursor(sr,sc);
	while((ascii=(int)getch())!=13)
	{
		if(count>size-2&&ascii!=8)
		{
		drawcursor(sr+inc,sc);
		continue;
		}
		if(count<=0)
		{
		setcolor(0);
		line(sr,sc,sr,sc+10);
		continue;
		}
		   if(ascii==8 && count>1)
		{
		count--;
		inc-=8;
		setfillstyle(1,col);
		string[count-1]='\0'; 	      //the selected letter is assigned null character.
		bar(sr+inc,sc,sr+inc+8,sc+10);
		drawcursor(sr+inc,sc);                  //cursor should come before any letter
		continue;
		}
		   if(ascii==9)                    //if tab key is pressed then break out of loop.
		   break;

		   if((ascii>0&&ascii<32)||ascii>126)
		{
		drawcursor(sr+inc,sc);
		continue;
		}
		if(ascii==0)
		{
		   ascii=(int)getch();
		   drawcursor(sr+inc,sc);
		   continue;
		  }

	string[count-1]=ascii;
	string[count]='\0';
	setfillstyle(1,col);
	bar(sr+inc,sc,sr+inc+8,sc+10);
	setcolor(15);
	outtextxy(sr,sc,string);
	drawcursor(sr+8+inc,sc);                 //cursor should come beyond any letter.
	count++;
	inc+=8;
	}                                        //end of while.
	string[count]='\0';                      //for tab key.
	setfillstyle(1,col);
	bar(sr+inc,sc,sr+inc+8,sc+10);
	setcolor(15);
	outtextxy(sr,sc,string);
	break;
	}                   //end of switch.

}

//to create a cursor.
void drawcursor(int sr,int sc)
{
while(!kbhit())                         //until a key is hitten.
	{
	setcolor(0);
	line(sr,sc,sr,sc+10);
	delay(120);
	setcolor(15);
	line(sr,sc,sr,sc+10);
	delay(50);
	}

}

//to draw a raised 3-D bar.
void threedbar(int x,int y,int height,int length,int color,int dir)
{
switch(dir)
{
case 1:
	setfillstyle(1,0);
	bar(x,y,x+length+10,y+height);
	setfillstyle(1,15);
	bar(x,y,x+length+9,y+height-1);
	setfillstyle(1,color);
	bar(x+1,y+1,x+length+9,y+height-1);
	break;
case 0:
	setfillstyle(1,0);
	bar(x,y,x+length+10,y-height);
	setfillstyle(1,15);
	bar(x,y-1,x+length+9,y-(height+1));
	setfillstyle(1,color);
	bar(x+1,y-1,x+length+9,y-(height+1));
	break;
	}
}

void label(int sr,int sc,int fcol,int bcol,char *name)
{
int len;
len=strlen(name);
setcolor(bcol);
setlinestyle(0,0,1);
rectangle(sr,sc,sr+len*10,sc+15);
len+=len+3;
len/=2;
setcolor(fcol);
outtextxy(sr+len,sc+4,name);
}

int deletemessage(int sr,int sc,int er,int ec)
{
static char *delbut[2]={"YES","NO"};
int choice;
void *buffer;
unsigned size;
size=imagesize(sr,sc,er+10,ec);
buffer=malloc(size);
getimage(sr,sc,er+10,ec,buffer);
threedbar(sr,sc,ec-sc,er-sr,7,1);
drawbox(sr+4,sc+2,er+8,ec-2,1,0,1);
drawbox(sr+6,sc+4,er+6,sc+20,1,7,3);
setcolor(15);
outtextxy(sr+10,sc+8,"Delete");
setcolor(4);
outtextxy(sr+20,sc+30,"Are you sure to delete ?");
drawbox(sr+42,sc+48,sr+218,sc+72,0,0,2);
displaybuttons(delbut,2,80,sr+45,sc+50);
choice=buttonresponse(delbut,2,80,sr+45,sc+50);
putimage(sr,sc,buffer,0);
free(buffer);
return(choice);
}

void errmessage(char *title,char *message,int sr,int sc,int er,int ec)
{
static char *erbut[1]={"OK"};
void *buffer;
unsigned size;
size=imagesize(sr,sc,er+10,ec);
buffer=malloc(size);
getimage(sr,sc,er+10,ec,buffer);
threedbar(sr,sc,ec-sc,er-sr,7,1);
drawbox(sr+4,sc+2,er+8,ec-2,1,0,1);
drawbox(sr+6,sc+4,er+6,sc+20,1,7,3);
setcolor(15);
outtextxy(sr+10,sc+8,title);
setcolor(4);
outtextxy(sr+20,sc+30,message);
drawbox(sr+90,sc+48,sr+177,sc+72,0,0,2);
displaybuttons(erbut,1,80,sr+94,sc+50);
buttonresponse(erbut,1,80,sr+94,sc+50);
putimage(sr,sc,buffer,0);
free(buffer);
return;
}
