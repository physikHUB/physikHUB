void displayreportpage(void);
void createreport(void);
void marksheetplate(void);

void displayreportpage()
{
int choice;
displaymarksheet(10,45,610,420);
while(1)
   {
choice=buttonresponse(markbuttons,2,80,25,425);
switch(choice)
	{
	case 0:createreport();break;
	case 1:return;
	}
   }


}

void createreport()
{
int *ctr,count,choice1,choice2,choice3,choice4,choice5,choice6,choice7,choice8,marker;
float percent,fsum=0,psum=0,osum=0;
char temp[6];
readstudents();
readmarks();
choice1=batchrequery(75,80,155,95);
choice2=levelrequery(75,100,155,115);
count=DataGroupSection(buffgrp,choice2,1);
choice3=grouprequery(count,75,120,205,135);
count=DataGroupSection(buffsec,choice2,2);
choice4=sectionrequery(count,95,140,205,155);
count=extractStudent(choice1,choice2,choice3,choice4,pcount);
if(count==0)
	{
	errmessage("Data","No student avialable",200,240,460,320);
	return;
	}
choice5=comboscroll(staid,count,75,160,195);
choice6=yearrequery(65,180,155,195);
count=extractSubject(choice2,choice6);
choice7=termrequery(65,200,155,215);
marker=extractmark(staid[choice5],choice6,choice7,ctr);
count=0;
count=(*ctr);
if(marker<0)
	{
	errmessage("Data","No record avialable",200,240,460,320);
	return;
	}

marksheetplate();
choice1=0;
choice5=choice6=choice7=0;
for(choice1=0;choice1<count;choice1++)
{
choice2=marksheet[choice1].fm;
choice3=marksheet[choice1].pm;
choice4=marksheet[choice1].om;
markitem(marksheet[choice1].subid,choice2,choice3,choice4,232,100+choice1*15);
fsum+=marksheet[choice1].fm;
psum+=marksheet[choice1].pm;
osum+=marksheet[choice1].om;
}
itoa(fsum,temp,10);
setcolor(2);
outtextxy(328,359,temp);
itoa(psum,temp,10);
outtextxy(418,359,temp);
itoa(osum,temp,10);
outtextxy(508,359,temp);
percent=(osum/fsum)*100;
choice1=0;
choice1=(int)percent;
itoa(percent,temp,10);
outtextxy(344,388,temp);

if(marker>0||percent<35)
{
setcolor(4);
strcpy(temp,"FAIL");
}
else
	{
	if(percent>35&&percent<50)
	  {
	  setcolor(7);
	  strcpy(temp,"THIRD");
	  }
	else if(percent>50&&percent<60)
	  {
	setcolor(0);
	strcpy(temp,"SECOND");
	  }
	else if(percent>60&&percent<75)
	 {
	setcolor(1);
	strcpy(temp,"FIRST");
	 }
	else if(percent>75&&percent<=100)
	{
	setcolor(2);
	strcpy(temp,"DISTINCTION");
	}
    }
outtextxy(490,388,temp);
return;
}

void marksheetplate(void)
{
int i;
drawbox(212,71,618,454,15,0,3);
drawbox(230,75,600,100,15,7,3);
drawbox(230,350,600,420,15,7,3);
label(238,80,1,2,"SUBID");
label(310,80,1,2,"FULLMARK");
label(400,80,1,2,"PASSMARK");
label(490,80,1,2,"OBT. MARK");
label(238,355,1,2,"TOTAL");
drawbox(320,355,370,370,15,1,3);
drawbox(410,355,470,370,15,1,3);
drawbox(500,355,560,370,15,1,3);
label(238,385,1,2,"PERCENTAGE");
drawbox(340,385,390,400,15,1,3);
label(400,385,1,2,"DIVISION");
drawbox(485,385,590,400,15,1,3);
return;
}
