int levrequery(int,int,int,int);
int termrequery(int,int,int,int);
int batchrequery(int,int,int,int);
int sectionrequery(int,int,int,int,int);
int grouprequery(int,int,int,int,int);
int yearrequery(int,int,int,int);

int DataGroupSection(char *[],int,int);
int extractStudent(int,int,int,int,int);
int extractSubject(int,int);
int checkid(char *,char *,int);
void updatemarks(void);
void readmarks(void);
void savemarks(void);
void savescore(int);
void addmarks(void);
void displaymarks(void);
void deletemarks(void);
int checkstudent(char *,char *,int);
int checkmark(int,int);
int dataintegrity(char *);
int getposstudent(char *);
void savepupil(int);
void savestudents(void);
int getposition(char *,char *,int);
void sortstudents(int);
void sortmarks(int);

void marksheetgen(void);
int extractmark(char *,int,int,int*);

struct group{char grid[10];char levelid[5];};
struct section{char secid[8];char levelid[5];};
struct subject{char subid[9];char levelid[5];unsigned int yearid;unsigned int fm;unsigned int pm;};

struct studentDetails
{
char levelid[5];
char grid[10];
char secid[8];
char name[25];
unsigned int rollno;
unsigned int gender;
char batchid[7];
char stdid[8];
};

struct mark
{
int yearid;
int termid;
char subid[9];
unsigned int fm;
unsigned int pm;
unsigned int om;
char stdid[8];
};

struct group grp[3]={
			{"PHYSICS","BSC"},
			{"STAT","BSC"},
			{"NONE","BBS"}
			};
struct section room[5]= {
			{"BSCI","BSC"},
			{"BSCII","BSC"},
			{"BBSI","BBS"},
			{"BBSII","BBS"},
			{"BBSIII","BBS"}
			};

char *batch[5]={"2002","2003","2004","2005"};
char *level[2]={"BSC","BBS"};
int year[3]={1,2,3};
int terminal[4]={1,2,3,4};
char *saal[3]={"First","Second","Third"};
char *term[4]={"First","Second","Sentup","Board"};
char *sex[2]={"Male  ","Female"};
struct subject sub[49]={
		   {"CS311","BSC",1,100,35},{"CS312","BSC",1,50,20},{"CS321","BSC",2,100,35},
		   {"CS322","BSC",2,50,20},{"CS331","BSC",3,100,35},{"CS332","BSC",3,100,35},
		   {"CS333","BSC",3,50,20},{"CS334","BSC",3,50,20},{"MATH311","BSC",1,75,28},
		   {"MATH312","BSC",1,75,28},{"MATH321","BSC",2,75,28},{"MATH322","BSC",2,75,28},
		   {"MATH331","BSC",3,75,28},{"MATH332","BSC",3,75,28},{"MATH333","BSC",3,75,28},
		   {"MATH334","BSC",3,75,28},{"MATH335","BSC",3,75,28},{"PHY311","BSC",1,100,35},
		   {"PHY312","BSC",1,50,20},{"PHY321","BSC",2,100,35},{"PHY322","BSC",2,50,20},
		   {"PHY331","BSC",3,100,35},{"PHY332","BSC",3,100,35},{"PHY333","BSC",3,100,35},
		   {"STAT311","BSC",1,100,35},{"STAT312","BSC",1,50,20},{"STAT321","BSC",2,100,35},
		   {"STAT322","BSC",2,50,20},{"STAT331","BSC",3,100,35},{"STAT332","BSC",3,100,35},
		   {"STAT333","BSC",3,100,35},{"MGT201","BBS",1,100,35},{"MGT202","BBS",1,100,35},
		   {"MGT203","BBS",1,100,35},{"MGT204","BBS",2,100,35},{"MGT211","BBS",1,100,35},
		   {"MGT212","BBS",1,100,35},{"MGT214","BBS",2,100,35},{"MGT215","BBS",2,100,35},
		   {"MGT311","BBS",3,100,35},{"MGT312","BBS",3,100,35},{"MGT313","BBS",3,100,35},
		   {"MGT314","BBS",3,100,35},{"MGT315","BBS",3,100,35},{"MGT316","BBS",3,100,35},
		   {"MGT311","BBS",3,100,35},{"MGT321","BBS",3,100,35},{"MGT322","BBS",3,100,35},
		   {"MGT323","BBS",3,100,35},
		   };


struct mark marks[300];
struct subject subselect[15];
struct mark marksheet[15];
struct studentDetails pupils[100];
struct studentDetails pupilsel[35];
char *buffgrp[3];
char *buffsec[5];
char *staid[35];
char *staname[35];
char *subjectid[15];                            //maximum no of subjects for a particular selection.
//global variables.
int fcount=0;
int pcount=0;

int levelrequery(int sr,int sc,int er,int ec)
{
int choice;
choice=combobox(level,2,sr,sc,er,ec);
return(choice);
}

int batchrequery(int sr,int sc,int er,int ec)
{
int choice;
choice=combobox(batch,4,sr,sc,er,ec);
return(choice);
}

int sectionrequery(int count,int sr,int sc,int er,int ec)
{
int choice;
choice=combobox(buffsec,count,sr,sc,er,ec);
return(choice);
}

int grouprequery(int count,int sr,int sc,int er,int ec)
{
int choice;
choice=combobox(buffgrp,count,sr,sc,er,ec);
return(choice);
}

int yearrequery(int sr,int sc,int er,int ec)
{
int choice;
choice=combobox(saal,3,sr,sc,er,ec);
return(choice);
}

int termrequery(int sr,int sc,int er,int ec)
{
int choice;
choice=combobox(term,4,sr,sc,er,ec);
return(choice);
}

//to extract subject for given level and year from all the subjects.
int extractSubject(int levc,int yeac)
{
int count=0,count1=0,val1,val2,val;
while(count1<49)
{
val1=strcmp(level[levc],sub[count1].levelid);
val2=year[yeac]-sub[count1].yearid;
val=(val1||val2);
if(val==0)
  {
  subselect[count]=sub[count1];
  subjectid[count]=sub[count1].subid;
  count1++;
  count++;
  }
  else
  count1++;
}
return(count);
}

//to extract data for the group and section combobox depending on the level.
int DataGroupSection(char *arraybuff[],int choice,int opt)
{
int count1=0,count=0,val;
switch(opt)
	{
	case 1:
	while(count1<4)
		{
		val=strcmp(grp[count1].levelid,level[choice]);
		if(val==0)
			{
			arraybuff[count]=grp[count1].grid;
			count1++;
			count++;
			}
		else
		count1++;
		}
	break;
	case 2:
	while(count1<5)
		{
		val=strcmp(room[count1].levelid,level[choice]);
		if(val==0)
			{
			arraybuff[count]=room[count1].secid;
			count1++;
			count++;
			}
		else
		count1++;
		}
		break;
		}
return(count);
}

//to check for the stdid entered.
int checkid(char *id,char *samp,int ctr)
{
char temp[4];
int i,len,val,asc;
len=strlen(id);
setcolor(15);
if(len!=7)           //checking for  seven number of  characters.
return 0;

for(i=0;i<3;i++)
temp[i]=id[i];
temp[3]='\0';
if(strcmp(strupr(temp),strupr(samp))!=0)            //checking sxc as initials
	return 0;
	for(i=3;i<7;i++)                                   //checking for numbers.checking for characters except enter or tab key.
	{
	asc=(int)id[i];
	if(asc<48||asc>57)
	 return 0;
	}

for(i=0;i<ctr;)                        //checking for redundant ids.
	 {
	   val=strcmp(strupr(id),strupr(pupils[i].stdid));
	   if(val==0)
	  return 0;
	  else
	 i++;
	  }
return 1;
}

int dataintegrity(char *id)
{
int i,val;
for(i=0;i<fcount;)
	 {
	   val=strcmp(strupr(id),strupr(marks[i].stdid));
	   if(val==0)
	  return 0;
	  else
	 i++;
	  }
return 1;
}
//to read marks en bloc.
void readmarks()
{
FILE *fp;
fcount=0;
fp=fopen("marks.rec","rb");
while(fread(&marks[fcount],sizeof(marks[fcount]),1,fp)==1)
fcount++;
fclose(fp);
}

void savemarks()
{
FILE *fp;
fp=fopen("marks.rec","wb");
fwrite(marks,sizeof(marks[0]),fcount,fp);
fclose(fp);
}

//to extract marks for a particular student in many subjects.
int extractmark(char *id1,int id2,int id3,int *ctr)
{
int marker=0,val1,val2,val3,val,count=0,count1=0;
for(count1=0;count1<fcount;)
	{
	val1=strcmp(id1,marks[count1].stdid);
	val2=year[id2]-marks[count1].yearid;
	val3=terminal[id3]-marks[count1].termid;
	val=val1||val2||val3;
	if(val==0)
		{
		marksheet[count]=marks[count1];
		  if(marksheet[count].om<marksheet[count].pm)
		  marker+=1;
		  else
		 marker+=0;
		count1++;
		count++;
		}
	 else
	 {
	 count1++;
	 if(count1==fcount&&count==0)
		marker=-1;



	  }

 }

(*ctr)=count;
return(marker);
}

//to check for the uniqueness in mark record.
int checkstudent(char *id1,char *id2,int id3)
{
int i,val;
for(i=0;i<fcount;)                        //checking for redundant combination.
	 {
	   val=strcmp(id1,marks[i].stdid)||strcmp(id2,marks[i].subid)||(id3-marks[i].termid);
	   if(val==0)
	 {
	 //outtextxy(100,400,"The combination already exists");
	 return 0;
	 }
	   else
	i++;

	 }
return 1;
}

 //to check obtained mark with the fullmark.
int checkmark(int fm,int om)
{
if(om>fm)
return 0;
else
return 1;
}

//to get the position of record mark from the princile mark array.
int getposition(char *id1,char *id2,int id3)
{
int i,val,pos;
for(i=0;i<fcount;)
	{
	val=strcmp(id1,marks[i].stdid)||strcmp(id2,marks[i].subid)||id3-marks[i].termid;
	if(val==0)
	  {
	  pos=i;
	  break;
	  }
	  else
	  {
	  i++;
	  if(i==fcount)
	  pos=-1;
	   }
	 }
return(pos);
}

//to extract a student with the given batch,level,group and section.
int extractStudent(int batc,int levc,int grpc,int secc,int ctr)
{
int count=0,count1=0,val1,val2,val3,val4,val;
while(count1<ctr)
{
val1=strcmp(batch[batc],pupils[count1].batchid);
val2=strcmp(level[levc],pupils[count1].levelid);
val3=strcmp(buffgrp[grpc],pupils[count1].grid);
val4=strcmp(buffsec[secc],pupils[count1].secid);
val=(val1||val2||val3||val4);
if(val==0)
  {
  pupilsel[count]=pupils[count1];
  staid[count]=strupr(pupils[count1].stdid);
  staname[count]=strupr(pupils[count1].name);
  count1++;
  count++;
  }
  else
  count1++;

}
return(count);
}

//to sort students according to stdid,name,level.
void sortstudents(int choice)
{
struct studentDetails pupil;
int i,j,val;
for(i=0;i<pcount-1;i++)
	{
	for(j=i+1;j<pcount;j++)
	{
	switch(choice)
		{
	case 0:val=strcmp(pupils[i].stdid,pupils[j].stdid);break;
	case 1:val=strcmp(pupils[i].name,pupils[j].name);break;
	case 2:val=strcmp(pupils[i].levelid,pupils[j].levelid);break;
		}

	if(val>0)
		{
	   pupil=pupils[i];
	   pupils[i]=pupils[j];
	   pupils[j]=pupil;
	   }
	}
	}
return;
}


void sortmarks(int choice)
{
struct mark score;
int i,j,val;
for(i=0;i<fcount-1;i++)
	{
	for(j=i+1;j<fcount;j++)
	{
	switch(choice)
		{
	case 0:val=strcmp(marks[i].stdid,marks[j].stdid);break;
	case 1:val=strcmp(marks[i].subid,marks[j].subid);break;
		}

	if(val>0)
		{
	   score=marks[i];
	   marks[i]=marks[j];
	   marks[j]=score;
	   }
	}
	}
return;
}


//to get the position of a student from the principle student array pupils
int getposstudent(char *temp)
{
int i,val,pos;
for(i=0;i<pcount;)
	{
	val=strcmp(strupr(temp),strupr(pupils[i].stdid));
	if(val==0)
	  {
	  pos=i;
	  break;
	  }
	  else
	  {
	  i++;
	  if(i==pcount)
	  pos=-1;
	   }

	 }

return(pos);
}
//to or not to save changes in the principle student array.
void savepupil(int addflag)
{
if(addflag==0)
	{
	errmessage("Save","!! No changes made",200,240,450,320);
	return;
	}

else    {
	savestudents();
	errmessage("Save","Changes saved successfully",200,240,450,320);
	}

}
//to save the principle student array into the file pupil.rec.
void savestudents()
{
FILE *fp;
char *num;
fp=fopen("pupil.rec","wb");
fwrite(pupils,sizeof(pupils[0]),pcount,fp);
fclose(fp);
return;
}
//to read data into the principle structure array from the file pupil.rec.
void readstudents()
{
FILE *fp;
pcount=0;
fp=fopen("pupil.rec","rb");
while(fread(&pupils[pcount],sizeof(pupils[pcount]),1,fp)==1)
pcount++;
fclose(fp);
return;
}

void savescore(int addflag)
{
if(addflag==0)
	{
	errmessage("Save","!!No changes made",200,240,450,320);
	return;
	}

else
	{
savemarks();
errmessage("Save","Changes saved successfully",200,240,450,320);
	}
}
