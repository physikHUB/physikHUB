#include<stdio.h>
#include<conio.h>
#include<graphics.h>
#include<string.h>
#include<stdlib.h>
#include<ctype.h>
#include<dos.h>
#include<malloc.h>

#include "guieleme.c"
#include "arrange.c"
#include "datainout.c"
#include "designs.c"
#include "iopage.c"
#include "reports.c"

int mainserver(void);
int appliserver(void);
int studentserver(void);
int markserver(void);
int dserver(void);
int rserver(void);
int hserver(void);


void main()
{
int gm=DETECT,device,count,mchoice,esc_flag;
initgraph(&gm,&device,"C:\\turboc\\bgi");
cleardevice();
mainserver();
closegraph();
}

//main module.
int mainserver()
{
int mchoice,esc_flag;
mainscreen();
aboutus();
while(1)
{
mainscreen();
displaymenuh(mainmenu,6,10,27);
mchoice=getresponseh(mainmenu,6,10,27,0);
switch(mchoice)
{
	case 0:
	esc_flag=appliserver();
	break;
	case 1:
	esc_flag=studentserver();
	break;
	case 2:
	esc_flag=markserver();
	break;
	case 3:
	esc_flag=dserver();
	break;
	case 4:
	esc_flag=rserver();
	break;
	case 5:
	esc_flag=hserver();
	break;

}
if(esc_flag==ESC)
return 0;

}

}

int appliserver()
{
int achoice,esc_flag=0;
achoice=popupmenuv(submenu6,1,10,40,0);

switch(achoice)
{
		case 0:
		return ESC;
		case 75:     			 //left arrow key.
		menuitemh(mainmenu[0],10,27,0);
		menuitemh(mainmenu[5],560,27,1);
		esc_flag=hserver();
		menuitemh(mainmenu[5],560,27,0);
		break;
		case 77:                        //right arrow key.
		menuitemh(mainmenu[0],10,27,0);
		menuitemh(mainmenu[1],120,27,1);
		esc_flag=studentserver();
		menuitemh(mainmenu[1],120,27,0);
		break;
		}

return(esc_flag);
}

int studentserver()
{
int schoice,esc_flag=0;
schoice=popupmenuv(submenu1,3,120,40,6);
switch(schoice)
{
		case 0:
		addstudentpage();
		break;
		case 1:
		editstudentpage();
		break;
		case 2:
		deletestudentpage();
		break;
		case 75:      				//left arrow key.
		menuitemh(mainmenu[1],120,27,0);
		menuitemh(mainmenu[0],10,27,1);
		esc_flag=appliserver();
		menuitemh(mainmenu[0],10,27,1);
		break;
		case 77:                		//right arrow key.
		menuitemh(mainmenu[1],120,27,0);
		menuitemh(mainmenu[2],230,27,1);
		esc_flag=markserver();
		menuitemh(mainmenu[2],230,27,0);
		break;
		}

return(esc_flag);
}


int markserver()
{
int mchoice,esc_flag=0;
mchoice=popupmenuv(submenu2,3,230,40,9);
switch(mchoice)
	{
		case 0:
		addmarkpage();
		break;
		case 1:
		editmarkpage();
		break;
		case 2:
		deletemarkpage();
		break;
		case 75:      			//left arrow key.
		menuitemh(mainmenu[2],230,27,0);
		menuitemh(mainmenu[1],120,27,1);
		esc_flag=studentserver();
		menuitemh(mainmenu[1],120,27,0);
		break;
		case 77:
		menuitemh(mainmenu[2],230,27,0);
		menuitemh(mainmenu[3],340,27,1);
		esc_flag=dserver();
		menuitemh(mainmenu[3],340,27,0);
		break;

	}
return(esc_flag);
}


int dserver()
{
int dchoice,esc_flag=0;
dchoice=popupmenuv(submenu3,2,340,40,12);
switch(dchoice)
{
		case 0:
		displaystudentpage();
		break;
		case 1:
		displaymarkpage();
		break;
		case 75:     				 //left arrow key.
		menuitemh(mainmenu[3],340,27,0);
		menuitemh(mainmenu[2],230,27,1);
		esc_flag=markserver();
		menuitemh(mainmenu[2],230,27,0);
		break;
		case 77:
		menuitemh(mainmenu[3],340,27,0);        //right arrow key.
		menuitemh(mainmenu[4],450,27,1);
		esc_flag=rserver();
		menuitemh(mainmenu[4],450,27,0);
		break;
	 }
return(esc_flag);
}

int rserver()
{
int rchoice,esc_flag=0;
rchoice=popupmenuv(submenu4,1,410,40,14);
switch(rchoice)
{
		case 0:
		displayreportpage();break;
		case 75:      				//left arrow key.
		menuitemh(mainmenu[4],450,27,0);
		menuitemh(mainmenu[3],340,27,1);
		esc_flag=dserver();
		menuitemh(mainmenu[3],340,27,0);
		break;
		case 77:
		menuitemh(mainmenu[4],450,27,0);        //right arrow key.
		menuitemh(mainmenu[5],560,27,1);
		esc_flag=hserver();
		menuitemh(mainmenu[5],560,27,0);
		break;
		}

return(esc_flag);
}

int hserver()
{
int hchoice,esc_flag=0;
hchoice=popupmenuv(submenu5,2,410,40,16);
switch(hchoice)
{
		case 0:
		outtextxy(100,250,"Displays help in short cut form");
		break;
		case 1:
		outtextxy(110,250,"Displays help in detail");
		break;
		case 75:      				//left arrow key.
		menuitemh(mainmenu[5],560,27,0);
		menuitemh(mainmenu[4],450,27,1);
		esc_flag=rserver();
		menuitemh(mainmenu[4],450,27,0);
		break;
		case 77:                                //right arrow key.
		menuitemh(mainmenu[5],560,27,0);
		menuitemh(mainmenu[0],10,27,1);
		esc_flag=appliserver();
		menuitemh(mainmenu[0],10,27,0);
		break;
}
return(esc_flag);
}
