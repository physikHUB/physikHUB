int addstudentpage(void);
int editstudentpage(void);
int deletestudentpage(void);
int addpupil(void);
int deletepupil(void);
int editpupil(void);
void displaystudentpage(void);
void listpupil();

void addmarkpage(void);
int addscore(void);
void editmarkpage(void);
int editscore(void);
int deletescore(void);
void deletemarkpage(void);
void displaymarkpage(void);
void printmarks(int,int,int);
void listmark(void);

int addstudentpage()
{
int choice,addflag;
displayaddpupil(20,50);
addflag=0;
while(1)
{
choice=buttonresponse(addbuttons,3,80,40,410);
switch(choice)
	{
	case 0:addflag=addpupil();break;
	case 1:savepupil(addflag);addflag=0;break;
	case 2:case 27:return 0;

	}
}

}

int addpupil()
{
int choice1,choice2,choice3,choice4,choice5,choice6,count,chk;
char ch,*num,temp[5];
getch();
readstudents();
if(pcount>=200)   	//checking for maximum possible records.
	{
	errmessage("System","Can't enter beyond 100 records",200,240,480,320);
	return 0;
	}

choice1=batchrequery(96,85,220,100);
choice2=levelrequery(96,110,220,125);
count=DataGroupSection(buffgrp,choice2,1);
choice3=grouprequery(count,96,132,220,147);
count=DataGroupSection(buffsec,choice2,2);
choice4=sectionrequery(count,115,154,220,169);
count=extractStudent(choice1,choice2,choice3,choice4,pcount);
if(count>=35)
	{
	errmessage("System","Can't enter beyond 35 records",200,240,480,320);
	return 0;                     //to make addflag 0.
	}
drawbox(345,80,628,394,7,7,3);
tableresponse(staid,staname,count,20,340,90,500,1);
strcpy(pupils[pcount].batchid,strupr(batch[choice1]));
strcpy(pupils[pcount].levelid,strupr(level[choice2]));
strcpy(pupils[pcount].grid,strupr(buffgrp[choice3]));
strcpy(pupils[pcount].secid,strupr(buffsec[choice4]));
getstring(pupils[pcount].stdid,100,178,10,2,1);
chk=checkid(pupils[pcount].stdid,"SXC",pcount);
while(chk==0)
{
errmessage("Data","Invalid entry/ID already exists",200,240,480,320);
getstring(pupils[pcount].stdid,100,178,10,2,1);
chk=checkid(pupils[pcount].stdid,"SXC",pcount);
}
getnum(temp,110,202,5,2,1);
pupils[pcount].rollno=atoi(temp);
getstring(pupils[pcount].name,90,228,24,2,1);
choice6=optiongroup(sex,2,100,246,200);
if(choice6==0)
pupils[pcount].gender=1;
else if(choice6==1)
pupils[pcount].gender=0;
pcount++;
return 1;
}

int editstudentpage()
{
int eflag=0,choice;
displayeditpupil(20,50,600,400);
while(1)
{
choice=buttonresponse(editbuttons,3,80,325,395);
switch(choice)
	{
	case 0:eflag=editpupil();break;
	case 1:savepupil(eflag);eflag=0;break;
	case 2:return 1;
	}
}

}

int deletestudentpage()
{
int dflag=0,choice;
displaydeletepupil(20,50,600,400);
while(1)
   {
choice=buttonresponse(deletebuttons,3,80,325,395);
switch(choice)
	{
	case 0:dflag=deletepupil();break;
	case 1:savepupil(dflag);dflag=0;break;
	case 2:return 1;
	}
   }

}

void displaystudentpage()
{
int choice;
displaylistpupil(40,50,600,420);
while(1)
   {
choice=buttonresponse(listbuttons,2,80,355,440);
switch(choice)
	{
	case 0:listpupil();break;
	case 1:return;
	}
   }


}

void listpupil()
{
int choice;
static char *sortlist[3]={"STDID","NAME","LEVEL"};
readstudents();
choice=combobox(sortlist,3,115,75,225,90);
sortstudents(choice);
printstudents(46,116,600);
return;
}

int editpupil()
{
int choice1,choice2,choice3,choice4,choice5,choice6,count,pos;
char temp[6];
static char *modify[3]={"Name","Roll","Gender"};
readstudents();
sortstudents(0);
choice1=batchrequery(85,79,160,94);
choice2=levelrequery(220,79,300,94);
count=DataGroupSection(buffgrp,choice2,1);
choice3=grouprequery(count,360,79,460,94);
count=DataGroupSection(buffsec,choice2,2);
choice4=sectionrequery(count,540,79,615,94);
count=extractStudent(choice1,choice2,choice3,choice4,pcount);
if(count==0)                                //if there are no students available for that selection.
	{
	errmessage("Data","No student avialable",200,240,450,320);
	return 0;
	}
drawbox(28,116,307,417,7,7,3);                 //to clear previous list.
choice5=tableresponse(staid,staname,count,20,23,115,180,1);
drawbox(380,125,615,140,2,0,3);
drawbox(400,145,440,160,2,0,3);
drawbox(400,165,460,180,2,0,3);
setcolor(15);
outtextxy(385,129,strupr(pupilsel[choice5].name));
itoa(pupilsel[choice5].rollno,temp,10);
outtextxy(405,149,temp);
if(pupilsel[choice5].gender==1)
outtextxy(405,169,"MALE");
else
outtextxy(405,169,"FEMALE");
pos=getposstudent(pupilsel[choice5].stdid); //to get the position of the dataitem in the strcture array pupils.
choice6=combobox(modify,3,430,210,570,225);
setfillstyle(1,7);
bar(324,232,616,280);
choice1=0;
switch(choice6)
	{
	case 0:
	label(325,237,0,15,"NAME");
	getstring(pupils[pos].name,375,238,24,2,1);
	strcpy(pupilsel[choice5].name,strupr(pupils[pos].name));     // to temporarily change the buffer list.
	break;
	case 1:
	label(325,237,0,15,"ROLLNO");
	getstring(temp,392,238,6,2,1);
	pupils[pos].rollno=atoi(temp);
	pupilsel[choice5].rollno=atoi(temp);
	break;
	case 2:
	label(325,237,0,15,"GENDER");
	choice1=optiongroup(sex,2,390,237,480);
	if(choice1==0)
	    pupils[pos].gender=1;
	    else if(choice1==1)
	     pupils[pos].gender=0;
	 break;
	}

return 1;
}


int deletepupil()
{
int choice1,choice2,choice3,choice4,choice5,choice6,count,pos,chk;
char temp[6];
readstudents();
sortstudents(0);
readmarks();
choice1=batchrequery(85,79,160,94);
choice2=levelrequery(220,79,300,94);
count=DataGroupSection(buffgrp,choice2,1);
choice3=grouprequery(count,360,79,460,94);
count=DataGroupSection(buffsec,choice2,2);
choice4=sectionrequery(count,540,79,615,94);
count=extractStudent(choice1,choice2,choice3,choice4,pcount);
if(count==0)
	{
	errmessage("Data","No student avialable",200,240,450,320);
	return 0;
	}


drawbox(28,116,307,417,7,7,3);                 //to clear previous list.
choice5=tableresponse(staid,staname,count,20,23,115,180,1);
drawbox(380,125,470,140,2,0,3);
drawbox(370,145,580,160,2,0,3);
drawbox(390,165,450,180,2,0,3);
drawbox(390,185,450,200,2,0,3);
drawbox(400,205,460,220,2,0,3);
drawbox(380,225,470,240,2,0,3);
drawbox(380,245,440,260,2,0,3);
drawbox(380,265,440,280,2,0,3);

setcolor(15);
outtextxy(385,129,strupr(pupilsel[choice5].stdid));
outtextxy(385,150,strupr(pupilsel[choice5].name));
itoa(pupilsel[choice5].rollno,temp,10);
outtextxy(405,169,temp);
outtextxy(405,210,strupr(pupilsel[choice5].secid));
outtextxy(385,230,strupr(pupilsel[choice5].grid));
outtextxy(385,250,strupr(pupilsel[choice5].levelid));
outtextxy(385,270,strupr(pupilsel[choice5].batchid));
if(pupilsel[choice5].gender==1)
outtextxy(393,188,"MALE");
else
outtextxy(393,188,"FEMALE");
chk=dataintegrity(pupilsel[choice5].stdid);         //checking for the student in the array marks.
if(chk==0)
   {
   errmessage("Data","Violates database integrity",200,240,450,320);
   return 0;
   }

pos=getposstudent(pupilsel[choice5].stdid); 	//to get the position in the structure array.
choice1=0;
choice2=0;
choice1=deletemessage(200,240,450,320);
switch(choice1)
	{
	case 0:
	for(choice2=pos;choice2<pcount;choice2++)
	pupils[choice2]=pupils[choice2+1];
	pcount--;                                   //decreasing the no of items.
	break;
	case 1:return 0;
	}
return 1;
}


void printstudents(int sr,int sc,int er)
{
int num=21,i,inc=0;
char temp[6],tot[6];
setcolor(0);
setfillstyle(1,2);
bar3d(sr,sc,er+28,sc+21*15,0,0);
for(i=0;i<pcount;i++)
{
setcolor(1);
setfillstyle(1,15);
bar3d(sr,sc+inc,sr+71,sc+15+inc,0,0);
bar3d(sr+71,sc+inc,sr+247,sc+15+inc,0,0);
bar3d(sr+247,sc+inc,sr+303,sc+15+inc,0,0);
bar3d(sr+303,sc+inc,sr+352,sc+15+inc,0,0);
bar3d(sr+352,sc+inc,sr+401,sc+15+inc,0,0);
bar3d(sr+401,sc+inc,sr+465,sc+15+inc,0,0);
bar3d(sr+465,sc+inc,sr+530,sc+15+inc,0,0);
bar3d(sr+530,sc+inc,sr+583,sc+15+inc,0,0);
setcolor(0);
outtextxy(sr+4,sc+inc+4,strupr(pupils[i].stdid));
outtextxy(sr+76,sc+inc+4,strupr(pupils[i].name));
itoa(pupils[i].rollno,temp,10);
outtextxy(sr+255,sc+inc+4,temp);
outtextxy(sr+310,sc+inc+4,pupils[i].batchid);
outtextxy(sr+360,sc+inc+4,pupils[i].levelid);
outtextxy(sr+405,sc+inc+4,pupils[i].grid);
outtextxy(sr+470,sc+inc+4,pupils[i].secid);
if(pupils[i].gender==0)outtextxy(sr+535,sc+inc+4,"FEMALE");
if(pupils[i].gender==1)outtextxy(sr+535,sc+inc+4,"MALE");

drawbox(sr+199,sc+324,sr+285,sc+343,1,7,2);
drawbox(sr+199,sc+324,sr+284,sc+343,2,0,3);
itoa(i+1,temp,10);
itoa(pcount,tot,10);
setcolor(15);
outtextxy(sr+203,sc+330,temp);
outtextxy(sr+225,sc+330,"of");
outtextxy(sr+244,sc+330,tot);
inc+=15;
delay(100);
if((i+1)%num==0)
	{
	getch();
	setfillstyle(1,2);
	bar3d(sr,sc,er+28,sc+21*15,0,0);
	inc=0;
	}
}
return;
}

void addmarkpage()
{
int choice,addflag=0;
displayaddmark(50,50,500,350);
while(1)
	{
       choice=buttonresponse(addbuttons,3,80,65,360);
       switch(choice)
	      {
	      case 0:addflag=addscore();break;
	      case 1:savescore(addflag);addflag=0;break;
	      case 2:return;
	      }


	}

}

int addscore()
{
int count,choice1,choice2,choice3,choice4,choice5,choice6,choice7,choice8;
char temp[6];
readstudents();
readmarks();
if(fcount>=500)             //checking for possible no of records.
	{
	errmessage("System","Can't enter beyond 300 records",200,240,480,320);
	return 0;
	}
choice1=batchrequery(120,85,200,100);
choice2=levelrequery(120,105,200,120);
count=DataGroupSection(buffgrp,choice2,1);
choice3=grouprequery(count,120,125,250,140);
count=DataGroupSection(buffsec,choice2,2);
choice4=sectionrequery(count,140,145,250,160);
count=extractStudent(choice1,choice2,choice3,choice4,pcount);
if(count==0)
	{
	errmessage("Data","No student avialable",200,240,460,320);
	return 0;
	}
choice5=comboscroll(staid,count,120,165,240);
choice6=yearrequery(110,185,200,200);
count=extractSubject(choice2,choice6);
choice7=termrequery(110,205,200,220);
choice8=comboscroll(subjectid,count,140,225,250);

//data entry to the marks array of structure.
strcpy(marks[fcount].stdid,staid[choice5]);
strcpy(marks[fcount].subid,subselect[choice8].subid);
marks[fcount].yearid=year[choice6];
marks[fcount].termid=terminal[choice7];
choice1=0;
choice1=checkstudent(marks[fcount].stdid,marks[fcount].subid,marks[fcount].termid);
if(choice1==0)     //if the data exists.
	{
	errmessage("Data","Record already exists",200,240,450,320);
	return 0;
	}
	//if the data does not exist,enter marks.
drawbox(345,100,530,115,2,0,3);
drawbox(365,120,410,135,2,0,3);
drawbox(355,140,430,155,2,0,3);
drawbox(395,160,450,175,2,0,3);
drawbox(395,180,450,195,2,0,3);
setcolor(15);
outtextxy(350,103,pupilsel[choice5].name);
itoa(pupilsel[choice5].rollno,temp,10);
outtextxy(373,124,temp);
outtextxy(360,143,subselect[choice8].subid);
itoa(subselect[choice8].fm,temp,10);
outtextxy(400,163,temp);
itoa(subselect[choice8].pm,temp,10);
outtextxy(400,183,temp);
marks[fcount].fm=subselect[choice8].fm;
marks[fcount].pm=subselect[choice8].pm;
getnum(temp,400,202,6,2,1);
marks[fcount].om=atoi(temp);
choice2=0;
choice2=checkmark(marks[fcount].fm,marks[fcount].om);
while(choice2==0)
	      {
	      errmessage("Mark","Enter less than fullmark",200,240,460,320);
	      getnum(temp,400,202,6,2,1);
	      marks[fcount].om=atoi(temp);
	      choice2=checkmark(marks[fcount].fm,marks[fcount].om);
	      }

fcount++;
return 1;
}

void editmarkpage()
{
int choice,editflag=0;
displayeditmark(50,50,500,350);
while(1)
	{
       choice=buttonresponse(editbuttons,3,80,65,360);
       switch(choice)
	      {
	      case 0:editflag=editscore();break;
	      case 1:savescore(editflag);editflag=0;break;
	      case 2:return;
	      }


	}

}

int editscore()
{
int count,choice1,choice2,choice3,choice4,choice5,choice6,choice7,choice8,pos;
char temp[6];
readstudents();
readmarks();
choice1=batchrequery(120,85,200,100);
choice2=levelrequery(120,105,200,120);
count=DataGroupSection(buffgrp,choice2,1);
choice3=grouprequery(count,120,125,250,140);
count=DataGroupSection(buffsec,choice2,2);
choice4=sectionrequery(count,140,145,250,160);
count=extractStudent(choice1,choice2,choice3,choice4,pcount);
if(count==0)      //checking for extracted students.
	{
	errmessage("Data","No student avialable",200,240,460,320);
	return 0;
	}
choice5=comboscroll(staid,count,120,165,240);
choice6=yearrequery(110,185,200,200);
count=extractSubject(choice2,choice6);
choice7=termrequery(110,205,200,220);
choice8=comboscroll(subjectid,count,140,225,250);
//get position of the data item to be updated in the principle mark list.
pos=getposition(staid[choice5],subjectid[choice8],terminal[choice7]);
if(pos<0)
     {
     errmessage("Data","Record does not exist",200,240,460,320);
     return 0;
     }
drawbox(345,100,530,115,2,0,3);
drawbox(365,120,410,135,2,0,3);
drawbox(355,140,430,155,2,0,3);
drawbox(395,160,450,175,2,0,3);
drawbox(395,180,450,195,2,0,3);
drawbox(395,200,450,215,2,0,3);
setcolor(15);
outtextxy(350,103,pupilsel[choice5].name);
itoa(pupilsel[choice5].rollno,temp,10);
outtextxy(373,124,temp);
outtextxy(360,143,marks[pos].subid);
itoa(marks[pos].fm,temp,10);
outtextxy(400,163,temp);
itoa(marks[pos].pm,temp,10);
outtextxy(400,183,temp);
itoa(marks[pos].om,temp,10);
outtextxy(400,203,temp);
//enter updated mark.
getnum(temp,400,242,6,2,1);
marks[pos].om=atoi(temp);
choice2=0;
choice2=checkmark(marks[pos].fm,marks[pos].om);
while(choice2==0)
	      {
	      errmessage("Mark","Enter less than fullmark",200,240,460,320);
	      getnum(temp,400,242,6,2,1);
	      marks[pos].om=atoi(temp);
	      choice2=checkmark(marks[pos].fm,marks[pos].om);
	      }
return 1;
}

void deletemarkpage()
{
int choice,dflag=0;
displaydeletemark(50,50,500,350);
while(1)
	{
       choice=buttonresponse(deletebuttons,3,80,65,360);
       switch(choice)
	      {
	      case 0:dflag=deletescore();break;
	      case 1:savescore(dflag);dflag=0;break;
	      case 2:return;
	      }


	}

}

int deletescore()
{
int count,choice1,choice2,choice3,choice4,choice5,choice6,choice7,choice8,pos;
char temp[6];
readstudents();
readmarks();
choice1=batchrequery(120,85,200,100);
choice2=levelrequery(120,105,200,120);
count=DataGroupSection(buffgrp,choice2,1);
choice3=grouprequery(count,120,125,250,140);
count=DataGroupSection(buffsec,choice2,2);
choice4=sectionrequery(count,140,145,250,160);
count=extractStudent(choice1,choice2,choice3,choice4,pcount);
if(count==0)      //checking for extracted students.
	{
	errmessage("Data","No student avialable",200,240,460,320);
	return 0;
	}
choice5=comboscroll(staid,count,120,165,240);
choice6=yearrequery(110,185,200,200);
count=extractSubject(choice2,choice6);
choice7=termrequery(110,205,200,220);
choice8=comboscroll(subjectid,count,140,225,250);
//get position of the data item to be deleted in the principle mark list.
pos=getposition(staid[choice5],subjectid[choice8],terminal[choice7]);
if(pos<0)
     {
     errmessage("Data","Record does not exist",200,240,460,320);
     return 0;
     }
drawbox(345,100,530,115,2,0,3);
drawbox(365,120,410,135,2,0,3);
drawbox(355,140,430,155,2,0,3);
drawbox(395,160,450,175,2,0,3);
drawbox(395,180,450,195,2,0,3);
drawbox(395,200,450,215,2,0,3);
setcolor(15);
outtextxy(350,103,pupilsel[choice5].name);
itoa(pupilsel[choice5].rollno,temp,10);
outtextxy(373,124,temp);
outtextxy(360,143,marks[pos].subid);
itoa(marks[pos].fm,temp,10);
outtextxy(400,163,temp);
itoa(marks[pos].pm,temp,10);
outtextxy(400,183,temp);
itoa(marks[pos].om,temp,10);
outtextxy(400,203,temp);
choice1=0;
choice2=0;
choice1=deletemessage(200,240,450,320);
switch(choice1)
	{
	case 0:
	for(choice2=pos;choice2<fcount;choice2++)
	marks[choice2]=marks[choice2+1];
	fcount--;                                   //decreasing the no of items.
	break;
	case 1:return 0;
	}


return 1;
}

void displaymarkpage()
{
int choice;
displaylistmark(40,50,600,420);
while(1)
   {
choice=buttonresponse(listbuttons,2,80,355,440);
switch(choice)
	{
	case 0:listmark();break;
	case 1:return;
	}
   }


}


void listmark()
{
int choice;
static char *sortlist[2]={"STDID","SUBID"};
readmarks();
choice=combobox(sortlist,2,115,75,225,90);
sortmarks(choice);
printmarks(46,116,600);
return;
}


void printmarks(int sr,int sc,int er)
{
int num=21,i,inc=0;
char temp[6],tot[6];
setcolor(0);
setfillstyle(1,2);
bar3d(sr,sc,er+28,sc+21*15,0,0);
for(i=0;i<fcount;i++)
{
setcolor(1);
setfillstyle(1,15);
bar3d(sr,sc+inc,sr+71,sc+15+inc,0,0);
bar3d(sr+71,sc+inc,sr+142,sc+15+inc,0,0);
bar3d(sr+142,sc+inc,sr+198,sc+15+inc,0,0);
bar3d(sr+198,sc+inc,sr+254,sc+15+inc,0,0);
bar3d(sr+254,sc+inc,sr+336,sc+15+inc,0,0);
bar3d(sr+336,sc+inc,sr+416,sc+15+inc,0,0);
bar3d(sr+416,sc+inc,sr+518,sc+15+inc,0,0);
bar3d(sr+518,sc+inc,sr+583,sc+15+inc,0,0);
setcolor(0);
outtextxy(sr+4,sc+inc+4,marks[i].stdid);
outtextxy(sr+76,sc+inc+4,marks[i].subid);
if(marks[i].yearid==1)outtextxy(sr+145,sc+inc+4,saal[0]);
if(marks[i].yearid==2)outtextxy(sr+145,sc+inc+4,saal[1]);
if(marks[i].yearid==3)outtextxy(sr+145,sc+inc+4,saal[2]);

if(marks[i].termid==1)outtextxy(sr+202,sc+inc+4,term[0]);
if(marks[i].termid==2)outtextxy(sr+202,sc+inc+4,term[1]);
if(marks[i].termid==3)outtextxy(sr+202,sc+inc+4,term[2]);
if(marks[i].termid==4)outtextxy(sr+202,sc+inc+4,term[3]);
itoa(marks[i].fm,temp,10);
outtextxy(sr+270,sc+inc+4,temp);
itoa(marks[i].pm,temp,10);
outtextxy(sr+350,sc+inc+4,temp);
itoa(marks[i].om,temp,10);
outtextxy(sr+435,sc+inc+4,temp);
if(marks[i].pm>marks[i].om)
	{
	setcolor(4);
	outtextxy(sr+522,sc+inc+4,"FAIL");
	}
else
	{
	setcolor(2);
	outtextxy(sr+522,sc+inc+4,"PASS");
	}

drawbox(sr+199,sc+324,sr+285,sc+343,1,7,2);
drawbox(sr+199,sc+324,sr+284,sc+343,2,0,3);
itoa(i+1,temp,10);
itoa(fcount,tot,10);
setcolor(15);
outtextxy(sr+203,sc+330,temp);
outtextxy(sr+225,sc+330,"of");
outtextxy(sr+244,sc+330,tot);
inc+=15;
delay(100);
if((i+1)%num==0)
	{
	getch();
	setfillstyle(1,2);
	bar3d(sr,sc,er+28,sc+21*15,0,0);
	inc=0;
	}
}
return;
}



