void displayaddpupil(int,int);
void displayeditpupil(int,int,int,int);
void displaydeletepupil(int,int,int,int);
void displayaddmark(int,int,int,int);
void displayeditmark(int,int,int,int);
void displaydeletemark(int,int,int,int);
void displaymarksheet(int,int,int,int);
void markitem(char *,int,int,int,int,int);
void displaylistpupil(int,int,int,int);
void displaylistmark(int,int,int,int);
void printstudents(int,int,int);
void printmarks(int,int,int);

char *addbuttons[3]={"ADD","SAVE","CANCEL"};
char *editbuttons[3]={"UPDATE","SAVE","CANCEL"};
char *deletebuttons[3]={"DELETE","SAVE","CANCEL"};
char *markbuttons[2]={"CREATE","CANCEL"};
char *listbuttons[2]={"TRAVERSE","CANCEL"};

//interface to add student.
void displayaddpupil(int sr,int sc)
{
static char *data1[2]={"Male","Female"};
threedbar(sr,sc,sc+350,sr+590,7,1);
drawbox(sr+2,sc+2,sr+615,sc+18,1,7,3);
drawbox(sr+2,sc+20,sr+615,sc+396,0,0,1);
drawbox(sr+10,sc+30,sr+315,sc+350,0,0,2);
drawbox(sr+322,sc+30,610,sc+346,0,0,2);
tablehead(sr+326,sc+31);
setcolor(15);
outtextxy(sr+10,sc+6,"AddStudents");
drawbox(sr+10,sc+355,sr+315,sc+385,0,0,2);
label(sr+15,sc+35,0,15,"BATCH");
combooutline(sr+76,sc+35,sr+200,sc+50,0,0);
label(sr+15,sc+60,0,15,"LEVEL");
combooutline(sr+76,sc+60,sr+200,sc+75,0,0);
label(sr+15,sc+82,0,15,"GROUP");
combooutline(sr+76,sc+82,sr+200,sc+97,0,0);
label(sr+15,sc+104,0,15,"SECTION");
combooutline(sr+95,sc+104,sr+200,sc+119,0,0);
label(sr+15,sc+126,0,15,"STDID");
drawbox(sr+76,sc+124,sr+180,sc+143,1,7,2);
drawbox(sr+77,sc+125,sr+179,sc+142,2,2,3);
label(sr+15,sc+150,0,15,"ROLLNO");
drawbox(sr+86,sc+148,sr+139,sc+167,1,7,2);
drawbox(sr+87,sc+149,sr+138,sc+166,2,2,3);
label(sr+15,sc+173,0,15,"NAME");
drawbox(sr+67,sc+174,sr+310,sc+192,1,7,2);
drawbox(sr+68,sc+175,sr+309,sc+191,2,2,3);
label(sr+15,sc+196,0,15,"GENDER");
displayoption(data1,2,sr+80,sc+196,sr+180);
displaybuttons(addbuttons,3,80,sr+20,sc+360);
return;
}
//interface to edit a student.
void displayeditpupil(int sr,int sc,int er,int ec)
{
char *data1[2],*data2[2];
threedbar(sr,sc,ec,er,7,1);
drawbox(sr+2,sc+2,er+25,sc+18,1,7,3);
setcolor(15);
outtextxy(sr+10,sc+6,"EditStudents");
drawbox(sr+2,sc+20,er+25,ec+48,0,0,1);
drawbox(sr+5,sc+25,er+20,sc+50,0,0,2);
label(sr+10,sc+29,0,15,"BATCH");combooutline(sr+65,sc+29,sr+140,sc+44,0,0);
label(sr+145,sc+29,0,15,"LEVEL");combooutline(sr+200,sc+29,sr+280,sc+44,0,0);
label(sr+285,sc+29,0,15,"GROUP");combooutline(sr+340,sc+29,sr+440,sc+44,0,0);
label(sr+445,sc+29,0,15,"SECTION");combooutline(sr+520,sc+29,sr+595,sc+44,0,0);
tablehead(sr+9,sc+56);
drawbox(sr+5,sc+55,sr+290,ec+20,0,0,2);
drawbox(sr+300,sc+55,er+20,sc+136,0,0,2);
threedbar(sr+301,sc+56,12,238,7,1);
setcolor(4);
outtextxy(sr+380,sc+58,"CURRENT DATA");
label(sr+305,sc+75,0,15,"NAME");
label(sr+305,sc+95,0,15,"ROLLNO");
label(sr+305,sc+115,0,15,"GENDER");
drawbox(sr+360,sc+75,er+15,sc+90,2,0,3);
drawbox(sr+380,sc+95,sr+420,sc+110,2,0,3);
drawbox(sr+380,sc+115,sr+440,sc+130,2,0,3);
drawbox(sr+300,sc+140,er+20,ec-100,0,0,2);
threedbar(sr+301,sc+141,12,238,7,1);
setcolor(4);
outtextxy(sr+380,sc+143,"UPDATED DATA");
label(sr+305,sc+160,0,15,"TO UPDATE");
combooutline(sr+410,sc+160,er-30,sc+175,0,0);
drawbox(sr+300,ec-10,er+20,ec+20,0,0,2);
displaybuttons(editbuttons,3,80,sr+305,ec-5);
return;
}
//interface to delete a student.
void displaydeletepupil(int sr,int sc,int er,int ec)
{
char *data1[2],*data2[2];
threedbar(sr,sc,ec,er,7,1);
drawbox(sr+2,sc+2,er+25,sc+18,1,7,3);
setcolor(15);
outtextxy(sr+10,sc+6,"DeleteStudents");
drawbox(sr+2,sc+20,er+25,ec+48,0,0,1);
drawbox(sr+5,sc+25,er+20,sc+50,0,0,2);
label(sr+10,sc+29,0,15,"BATCH");combooutline(sr+65,sc+29,sr+140,sc+44,0,0);
label(sr+145,sc+29,0,15,"LEVEL");combooutline(sr+200,sc+29,sr+280,sc+44,0,0);
label(sr+285,sc+29,0,15,"GROUP");combooutline(sr+340,sc+29,sr+440,sc+44,0,0);
label(sr+445,sc+29,0,15,"SECTION");combooutline(sr+520,sc+29,sr+595,sc+44,0,0);
tablehead(sr+9,sc+56);
drawbox(sr+5,sc+55,sr+290,ec+20,0,0,2);
drawbox(sr+300,sc+55,er+20,ec-20,0,0,2);
threedbar(sr+301,sc+56,12,238,7,1);
setcolor(4);
outtextxy(sr+380,sc+58,"CURRENT DATA");
label(sr+305,sc+75,0,15,"STDID");
label(sr+305,sc+95,0,15,"NAME");
label(sr+305,sc+115,0,15,"ROLLNO");
label(sr+305,sc+135,0,15,"GENDER");
label(sr+305,sc+155,0,15,"SECTION");
label(sr+305,sc+175,0,15,"GROUP");
label(sr+305,sc+195,0,15,"LEVEL");
label(sr+305,sc+215,0,15,"BATCH");
drawbox(sr+360,sc+75,sr+450,sc+90,2,0,3);
drawbox(sr+350,sc+95,sr+560,sc+110,2,0,3);
drawbox(sr+370,sc+115,sr+430,sc+130,2,0,3);
drawbox(sr+370,sc+135,sr+430,sc+150,2,0,3);
drawbox(sr+380,sc+155,sr+440,sc+170,2,0,3);
drawbox(sr+360,sc+175,sr+450,sc+190,2,0,3);
drawbox(sr+360,sc+195,sr+420,sc+210,2,0,3);
drawbox(sr+360,sc+215,sr+420,sc+230,2,0,3);
drawbox(sr+300,ec-10,er+20,ec+20,0,0,2);
displaybuttons(deletebuttons,3,80,sr+305,ec-5);
return;
}

//interface to add marks.
void displayaddmark(int sr,int sc,int er,int ec)
{
threedbar(sr,sc,ec,er,7,1);
drawbox(sr+2,sc+2,er+55,sc+18,1,7,3);
setcolor(15);
outtextxy(sr+10,sc+6,"AddMarks");
drawbox(sr+2,sc+20,er+55,ec+48,0,0,1);
drawbox(sr+10,sc+30,sr+240,sc+300,0,0,2);
drawbox(sr+245,sc+30,er+50,sc+300,0,0,2);
drawbox(sr+10,ec+5,sr+300,ec+36,0,0,2);
displaybuttons(addbuttons,3,80,sr+15,ec+10);
label(sr+15,sc+35,0,15,"BATCH");
combooutline(sr+70,sc+35,sr+150,sc+50,0,0);
label(sr+15,sc+55,0,15,"LEVEL");
combooutline(sr+70,sc+55,sr+150,sc+70,0,0);
label(sr+15,sc+75,0,15,"GROUP");
combooutline(sr+70,sc+75,sr+200,sc+90,0,0);
label(sr+15,sc+95,0,15,"SECTION");
combooutline(sr+90,sc+95,sr+200,sc+110,0,0);
label(sr+15,sc+115,0,15,"STDID");
combooutline(sr+70,sc+115,sr+190,sc+130,0,0);
label(sr+15,sc+135,0,15,"YEAR");
combooutline(sr+60,sc+135,sr+150,sc+150,0,0);
label(sr+15,sc+155,0,15,"TERM");
combooutline(sr+60,sc+155,sr+150,sc+170,0,0);
label(sr+15,sc+175,0,15,"SUBJECT");
combooutline(sr+90,sc+175,sr+200,sc+190,0,0);
threedbar(sr+246,sc+31,15,200,7,1);
setcolor(4);
outtextxy(sr+290,sc+34,"ADDING DATA");
label(sr+250,sc+50,0,15,"NAME");
drawbox(sr+295,sc+50,er+30,sc+65,2,0,3);
label(sr+250,sc+70,0,15,"ROLLNO");
drawbox(sr+315,sc+70,er-90,sc+85,2,0,3);
label(sr+250,sc+90,0,15,"SUBID");
drawbox(sr+305,sc+90,er-70,sc+105,2,0,3);
label(sr+250,sc+110,0,15,"FULL MARK");
drawbox(sr+345,sc+110,er-50,sc+125,2,0,3);
label(sr+250,sc+130,0,15,"PASS MARK");
drawbox(sr+345,sc+130,er-50,sc+145,2,0,3);
label(sr+250,sc+150,0,15,"OBT. MARK");
drawbox(sr+346,sc+148,sr+410,sc+167,1,7,2);
drawbox(sr+347,sc+149,sr+409,sc+166,2,2,3);
return;
}

//interface to edit marks.
void displayeditmark(int sr,int sc,int er,int ec)
{
char *temp;
threedbar(sr,sc,ec,er,7,1);
drawbox(sr+2,sc+2,er+55,sc+18,1,7,3);
setcolor(15);
outtextxy(sr+10,sc+6,"EditMarks");
drawbox(sr+2,sc+20,er+55,ec+48,0,0,1);
drawbox(sr+10,sc+30,sr+240,sc+300,0,0,2);
drawbox(sr+245,sc+30,er+50,sc+300,0,0,2);
drawbox(sr+10,ec+5,sr+300,ec+36,0,0,2);
displaybuttons(editbuttons,3,80,sr+15,ec+10);
label(sr+15,sc+35,0,15,"BATCH");
combooutline(sr+70,sc+35,sr+150,sc+50,0,0);
label(sr+15,sc+55,0,15,"LEVEL");
combooutline(sr+70,sc+55,sr+150,sc+70,0,0);
label(sr+15,sc+75,0,15,"GROUP");
combooutline(sr+70,sc+75,sr+200,sc+90,0,0);
label(sr+15,sc+95,0,15,"SECTION");
combooutline(sr+90,sc+95,sr+200,sc+110,0,0);
label(sr+15,sc+115,0,15,"STDID");
combooutline(sr+70,sc+115,sr+190,sc+130,0,0);
label(sr+15,sc+135,0,15,"YEAR");
combooutline(sr+60,sc+135,sr+150,sc+150,0,0);
label(sr+15,sc+155,0,15,"TERM");
combooutline(sr+60,sc+155,sr+150,sc+170,0,0);
label(sr+15,sc+175,0,15,"SUBJECT");
combooutline(sr+90,sc+175,sr+200,sc+190,0,0);
threedbar(sr+246,sc+31,15,200,7,1);
setcolor(4);
outtextxy(sr+290,sc+34,"CURRENT DATA");
label(sr+250,sc+50,0,15,"NAME");
drawbox(sr+295,sc+50,er+30,sc+65,2,0,3);
label(sr+250,sc+70,0,15,"ROLLNO");
drawbox(sr+315,sc+70,er-90,sc+85,2,0,3);
label(sr+250,sc+90,0,15,"SUBID");
drawbox(sr+305,sc+90,er-70,sc+105,2,0,3);
label(sr+250,sc+110,0,15,"FULL MARK");
drawbox(sr+345,sc+110,er-50,sc+125,2,0,3);
label(sr+250,sc+130,0,15,"PASS MARK");
drawbox(sr+345,sc+130,er-50,sc+145,2,0,3);
label(sr+250,sc+150,0,15,"OBT. MARK");
drawbox(sr+345,sc+150,er-50,sc+165,2,0,3);
threedbar(sr+246,sc+170,15,200,7,1);
setcolor(4);
outtextxy(sr+290,sc+174,"UPDATED DATA");
label(sr+250,sc+190,0,15,"OBT. MARK");
drawbox(sr+346,sc+188,sr+410,sc+207,1,7,2);
drawbox(sr+347,sc+189,sr+409,sc+206,2,2,3);
return;
}

//interface to delete marks.
void displaydeletemark(int sr,int sc,int er,int ec)
{
char *temp;
threedbar(sr,sc,ec,er,7,1);
drawbox(sr+2,sc+2,er+55,sc+18,1,7,3);
setcolor(15);
outtextxy(sr+10,sc+6,"DeleteMarks");
drawbox(sr+2,sc+20,er+55,ec+48,0,0,1);
drawbox(sr+10,sc+30,sr+240,sc+300,0,0,2);
drawbox(sr+245,sc+30,er+50,sc+300,0,0,2);
drawbox(sr+10,ec+5,sr+300,ec+36,0,0,2);
displaybuttons(deletebuttons,3,80,sr+15,ec+10);
label(sr+15,sc+35,0,15,"BATCH");
combooutline(sr+70,sc+35,sr+150,sc+50,0,0);
label(sr+15,sc+55,0,15,"LEVEL");
combooutline(sr+70,sc+55,sr+150,sc+70,0,0);
label(sr+15,sc+75,0,15,"GROUP");
combooutline(sr+70,sc+75,sr+200,sc+90,0,0);
label(sr+15,sc+95,0,15,"SECTION");
combooutline(sr+90,sc+95,sr+200,sc+110,0,0);
label(sr+15,sc+115,0,15,"STDID");
combooutline(sr+70,sc+115,sr+190,sc+130,0,0);
label(sr+15,sc+135,0,15,"YEAR");
combooutline(sr+60,sc+135,sr+150,sc+150,0,0);
label(sr+15,sc+155,0,15,"TERM");
combooutline(sr+60,sc+155,sr+150,sc+170,0,0);
label(sr+15,sc+175,0,15,"SUBJECT");
combooutline(sr+90,sc+175,sr+200,sc+190,0,0);
threedbar(sr+246,sc+31,15,200,7,1);
setcolor(4);
outtextxy(sr+290,sc+34,"CURRENT DATA");
label(sr+250,sc+50,0,15,"NAME");
drawbox(sr+295,sc+50,er+30,sc+65,2,0,3);
label(sr+250,sc+70,0,15,"ROLLNO");
drawbox(sr+315,sc+70,er-90,sc+85,2,0,3);
label(sr+250,sc+90,0,15,"SUBID");
drawbox(sr+305,sc+90,er-70,sc+105,2,0,3);
label(sr+250,sc+110,0,15,"FULL MARK");
drawbox(sr+345,sc+110,er-50,sc+125,2,0,3);
label(sr+250,sc+130,0,15,"PASS MARK");
drawbox(sr+345,sc+130,er-50,sc+145,2,0,3);
label(sr+250,sc+150,0,15,"OBT. MARK");
drawbox(sr+345,sc+150,er-50,sc+165,2,0,3);
return;
}
//interface to display marksheet.
void displaymarksheet(int sr,int sc,int er,int ec)
{
int i;
threedbar(sr,sc,ec,er,7,1);
drawbox(sr+2,sc+2,er+15,sc+18,1,7,3);
drawbox(sr+4,sc+20,er+15,ec+40,1,7,1);
drawbox(sr+4,sc+20,er+15,ec+40,1,7,1);
drawbox(sr+200,sc+25,er+10,ec+35,1,7,2);
drawbox(sr+202,sc+26,er+8,ec+34,15,0,3);
settextstyle(10,0,1);
setcolor(58);
outtextxy(sr+300,sc+180,"REPORT-CARD");
settextstyle(0,0,1);
setcolor(15);
outtextxy(sr+10,sc+6,"ReportCard");
label(sr+10,sc+35,0,15,"BATCH");
combooutline(sr+65,sc+35,sr+145,sc+50,0,0);
label(sr+10,sc+55,0,15,"LEVEL");
combooutline(sr+65,sc+55,sr+145,sc+70,0,0);
label(sr+10,sc+75,0,15,"GROUP");
combooutline(sr+65,sc+75,sr+195,sc+90,0,0);
label(sr+10,sc+95,0,15,"SECTION");
combooutline(sr+85,sc+95,sr+195,sc+110,0,0);
label(sr+10,sc+115,0,15,"STDID");
combooutline(sr+65,sc+115,sr+185,sc+130,0,0);
label(sr+10,sc+135,0,15,"YEAR");
combooutline(sr+55,sc+135,sr+145,sc+150,0,0);
label(sr+10,sc+155,0,15,"TERM");
combooutline(sr+55,sc+155,sr+145,sc+170,0,0);
drawbox(sr+10,ec,sr+190,ec+30,0,0,2);
displaybuttons(markbuttons,2,80,sr+15,ec+5);
}
//to display a mark structure item.
void markitem(char *sid,int fm,int pm,int om,int sr,int sc)
{
char temp[6];                               //array used instead of pointer.
setcolor(7);
setfillstyle(1,15);
bar3d(sr,sc,sr+72,sc+15,0,0);
bar3d(sr+72,sc,sr+162,sc+15,0,0);
bar3d(sr+162,sc,sr+252,sc+15,0,0);
bar3d(sr+252,sc,sr+363,sc+15,0,0);
setcolor(1);
outtextxy(sr+5,sc+4,sid);
itoa(fm,temp,10);
outtextxy(sr+92,sc+4,temp);
itoa(pm,temp,10);
outtextxy(sr+182,sc+4,temp);
if(om<pm)
setcolor(4);
else
setcolor(0);
itoa(om,temp,10);
outtextxy(sr+272,sc+4,temp);
}
//interface to display a list of students.
void displaylistpupil(int sr,int sc,int er,int ec )
{
threedbar(sr,sc,ec,er,7,1);
drawbox(sr+2,sc+2,er+35,sc+18,1,7,3);
drawbox(sr+4,sc+20,er+35,ec+45,1,7,1);
drawbox(sr+6,sc+50,er+30,ec+15,1,7,2);
settextstyle(10,0,1);
setcolor(15);
settextstyle(0,0,1);
outtextxy(sr+10,sc+6,"TraverseList");
label(sr+10,sc+25,0,15,"SORTBY");
combooutline(sr+75,sc+25,sr+185,sc+40,0,0);
label(sr+195,sc+25,0,15,"ORDER");
drawbox(sr+250,sc+25,sr+370,sc+40,2,0,3);
label(sr+120,ec+22,0,15,"RECORDS");
drawbox(sr+205,ec+20,sr+290,ec+40,1,7,2);
drawbox(sr+205,ec+20,sr+289,ec+39,2,0,3);
drawbox(sr+310,ec+18,er-70,ec+42,1,7,2);
displaybuttons(listbuttons,2,80,sr+315,ec+20);
threedbar(sr+7,sc+51,15,60,7,1);
threedbar(sr+78,sc+51,15,165,7,1);
threedbar(sr+254,sc+51,15,45,7,1);
threedbar(sr+310,sc+51,15,38,7,1);
threedbar(sr+359,sc+51,15,38,7,1);
threedbar(sr+408,sc+51,15,53,7,1);
threedbar(sr+472,sc+51,15,53,7,1);
threedbar(sr+536,sc+51,15,43,7,1);
setcolor(15);
outtextxy(sr+255,sc+29,"ASCENDING");
setcolor(4);
outtextxy(sr+20,sc+55,"STDID");
outtextxy(sr+105,sc+55,"STUDENT NAME");
outtextxy(sr+258,sc+55,"ROLLNO");
outtextxy(sr+313,sc+55,"BATCH");
outtextxy(sr+363,sc+55,"LEVEL");
outtextxy(sr+420,sc+55,"GROUP");
outtextxy(sr+475,sc+55,"SECTION");
outtextxy(sr+540,sc+55,"GENDER");
return;
}
//interface to display a list of marks.
void displaylistmark(int sr,int sc,int er,int ec )
{
threedbar(sr,sc,ec,er,7,1);
drawbox(sr+2,sc+2,er+35,sc+18,1,7,3);
drawbox(sr+4,sc+20,er+35,ec+45,1,7,1);
drawbox(sr+6,sc+50,er+30,ec+15,1,7,2);
settextstyle(10,0,1);
setcolor(15);
settextstyle(0,0,1);
outtextxy(sr+10,sc+6,"TraverseList");
label(sr+10,sc+25,0,15,"SORTBY");
combooutline(sr+75,sc+25,sr+185,sc+40,0,0);
label(sr+195,sc+25,0,15,"ORDER");
drawbox(sr+250,sc+25,sr+370,sc+40,2,0,3);
label(sr+120,ec+22,0,15,"RECORDS");
drawbox(sr+205,ec+20,sr+290,ec+40,1,7,2);
drawbox(sr+205,ec+20,sr+289,ec+39,2,0,3);
drawbox(sr+310,ec+18,er-70,ec+42,1,7,2);
displaybuttons(listbuttons,2,80,sr+315,ec+20);
threedbar(sr+7,sc+51,15,60,7,1);
threedbar(sr+78,sc+51,15,60,7,1);
threedbar(sr+149,sc+51,15,45,7,1);
threedbar(sr+205,sc+51,15,45,7,1);
threedbar(sr+261,sc+51,15,70,7,1);
threedbar(sr+342,sc+51,15,70,7,1);
threedbar(sr+423,sc+51,15,90,7,1);
threedbar(sr+524,sc+51,15,55,7,1);
setcolor(15);
outtextxy(sr+255,sc+29,"ASCENDING");
setcolor(4);
outtextxy(sr+20,sc+55,"STDID");
outtextxy(sr+90,sc+55,"SUBID");
outtextxy(sr+158,sc+55,"YEAR");
outtextxy(sr+215,sc+55,"TERM");
outtextxy(sr+265,sc+55,"FULL MARK");
outtextxy(sr+345,sc+55,"PASS MARK");
outtextxy(sr+427,sc+55,"SECURED MARK");
outtextxy(sr+530,sc+55,"REMARK");
return;
}
